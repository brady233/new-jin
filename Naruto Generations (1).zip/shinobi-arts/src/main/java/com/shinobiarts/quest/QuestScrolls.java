package com.shinobiarts.quest;

import com.shinobiarts.Config;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.JutsuRank;
import com.shinobiarts.jutsu.Jutsus;
import com.shinobiarts.registry.ModItems;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The jutsu scroll a random quest pays out on top of its EXP bottles and Ryo, rolled with the quest:
 * <ul>
 *   <li>Hourly: a D-rank scroll (the lowest).</li>
 *   <li>Daily: a C or B-rank scroll, with a small chance of an A or even an S-rank one.</li>
 *   <li>Weekly: a B-rank scroll, with a much better chance of A and S.</li>
 *   <li>Monthly: an A-rank scroll, often an S-rank one.</li>
 * </ul>
 * Only jutsu that have scrolls (not kekkei genkai jutsu). The chances are in General.toml (quests).
 */
public final class QuestScrolls {
    private QuestScrolls() {}

    /** A jutsu id for the scroll, or "" for none. */
    public static String roll(QuestPeriod period, Random random) {
        if (!Config.b(Config.QUEST_SCROLLS)) return "";
        double r = random.nextDouble();
        JutsuRank rank = switch (period) {
            case HOURLY -> JutsuRank.D;
            case DAILY -> r < Config.d(Config.QUEST_DAILY_S) ? JutsuRank.S
                    : r < Config.d(Config.QUEST_DAILY_S) + Config.d(Config.QUEST_DAILY_A) ? JutsuRank.A
                    : random.nextBoolean() ? JutsuRank.C : JutsuRank.B;
            case WEEKLY -> r < Config.d(Config.QUEST_WEEKLY_S) ? JutsuRank.S
                    : r < Config.d(Config.QUEST_WEEKLY_S) + Config.d(Config.QUEST_WEEKLY_A) ? JutsuRank.A : JutsuRank.B;
            case MONTHLY -> r < Config.d(Config.QUEST_MONTHLY_S) ? JutsuRank.S : JutsuRank.A;
        };
        // the rank asked for, or the nearest one below it that has scrolls (then above)
        for (int step = 0; step < JutsuRank.values().length; step++) {
            for (int dir : new int[]{-1, 1}) {
                int ord = rank.ordinal() + dir * step;
                if (ord < 0 || ord >= JutsuRank.values().length) continue;
                List<Jutsu> pool = new ArrayList<>();
                for (Jutsu j : Jutsus.all()) {
                    if (j.rank().ordinal() == ord && ModItems.JUTSU_SCROLLS.containsKey(j.id())) pool.add(j);
                }
                if (!pool.isEmpty()) return pool.get(random.nextInt(pool.size())).id();
                if (step == 0) break;
            }
        }
        return "";
    }
}
