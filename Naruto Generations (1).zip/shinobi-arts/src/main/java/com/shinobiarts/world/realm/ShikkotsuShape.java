package com.shinobiarts.world.realm;

import static com.shinobiarts.world.realm.RealmNoise.fbm;
import static com.shinobiarts.world.realm.RealmNoise.hash;

/**
 * Shikkotsu Forest: an endless misty forest of colossal trees — trunks ten blocks across rising over a hundred blocks
 * on buttress roots, branches spreading into vast canopies — over a mossy floor of podzol, ferns and slow streams. At
 * the arrival point a wooden temple sits in a clearing, reached through a torii and over a red bridge across a stream,
 * with stone lanterns and two small shrines.
 */
public final class ShikkotsuShape extends RealmShape {
    public ShikkotsuShape() {
        super(192);
    }

    static final int CLEARING = 66, FLAT = 42, BLEND = 26, WATER_LEVEL = 62, TREE_CELL = 30, SMALL_CELL = 9;

    @Override
    public int[] arrival() {
        return new int[]{0, CLEARING, -36};
    }

    static int ground(int x, int z) {
        double g = 65 + 4 * fbm(x, z, 90, 91) + 2 * fbm(x, z, 24, 92);
        double d = Math.hypot(x, z);
        double w = smooth((d - FLAT) / BLEND);
        double river = Math.abs(fbm(x + 500, z + 900, 170, 93));
        if (river < 0.09 && w > 0) {
            double bank = smooth((0.09 - river) / 0.05);
            g += (WATER_LEVEL - 2 - g) * bank * w;
        }
        g = CLEARING + (g - CLEARING) * w;
        if (d < FLAT + 10 && Math.abs(z + 14) <= 2 && Math.abs(x) <= 50) g = WATER_LEVEL;   // the temple's stream
        return (int) Math.round(g);
    }

    @Override
    protected void column(int x, int z, Chunk c) {
        int g = ground(x, z);
        double patch = fbm(x, z, 20, 94);
        for (int y = 0; y < g; y++) {
            int id;
            if (y == g - 1) id = g <= WATER_LEVEL ? GRAVEL : patch > 0.22 ? PODZOL : patch < -0.25 ? MOSS : GRASS;
            else if (y >= g - 4) id = DIRT;
            else id = y % 9 == 0 ? ANDESITE : STONE;
            c.set(x, y, z, id);
        }
        for (int y = g; y <= WATER_LEVEL + (Math.hypot(x, z) < FLAT + 10 && Math.abs(z + 14) <= 2 ? 2 : 0) && g <= WATER_LEVEL; y++) c.set(x, y, z, WATER);
        if (g > WATER_LEVEL) {
            double h = hash(x, z, 95);
            if (h < 0.09) c.set(x, g, z, FERN);
            else if (h < 0.14) c.set(x, g, z, MOSS_CARPET);
        }
        // the temple clearing: a stone path and plaza
        if (Math.hypot(x, z) < FLAT) {
            if (Math.abs(x) <= 1 && z >= -44 && z <= 12) clear(c, x, z, BRICKS);
            if (Math.abs(x) <= 13 && z >= -4 && z <= 22) clear(c, x, z, (x + z & 3) == 0 ? MOSSY_BRICKS : POLISHED);
        }
    }

    private static void clear(Chunk c, int x, int z, int id) {
        if (c.get(x, CLEARING - 1, z) == WATER) return;
        c.set(x, CLEARING - 1, z, id);
        c.set(x, CLEARING, z, AIR);
    }

    /** The giant tree in tree cell (i, j): {x, z, trunk radius*10, top}, or null. */
    static int[] tree(int i, int j) {
        if (hash(i, j, 101) > 0.78) return null;
        int x = i * TREE_CELL + 6 + (int) (hash(i, j, 102) * (TREE_CELL - 12));
        int z = j * TREE_CELL + 6 + (int) (hash(i, j, 103) * (TREE_CELL - 12));
        if (Math.hypot(x, z) < FLAT + 14) return null;
        int g = ground(x, z);
        if (g <= WATER_LEVEL + 1) return null;
        int r10 = 35 + (int) (hash(i, j, 104) * 30);
        int top = Math.min(176, g + 80 + (int) (hash(i, j, 105) * 50));
        return new int[]{x, z, r10, top};
    }

    @Override
    protected void structures(Chunk c) {
        int ti = Math.floorDiv(c.x0, TREE_CELL), tj = Math.floorDiv(c.z0, TREE_CELL);
        for (int i = ti - 1; i <= ti + 2; i++) {
            for (int j = tj - 1; j <= tj + 2; j++) {
                int[] t = tree(i, j);
                if (t != null && c.touches(t[0] - 36, t[1] - 36, t[0] + 36, t[1] + 36)) giantTree(c, t, i, j);
            }
        }
        int si = Math.floorDiv(c.x0, SMALL_CELL), sj = Math.floorDiv(c.z0, SMALL_CELL);
        for (int i = si - 1; i <= si + 2; i++) {
            for (int j = sj - 1; j <= sj + 2; j++) {
                if (hash(i, j, 111) > 0.32) continue;
                int x = i * SMALL_CELL + (int) (hash(i, j, 112) * SMALL_CELL), z = j * SMALL_CELL + (int) (hash(i, j, 113) * SMALL_CELL);
                if (!c.touches(x - 6, z - 6, x + 6, z + 6)) continue;
                int g = ground(x, z);
                if (g <= WATER_LEVEL + 1 || Math.hypot(x, z) < FLAT - 6) continue;
                if (nearGiant(x, z)) continue;
                int h = 6 + (int) (hash(i, j, 114) * 6);
                c.box(x, g, z, x, g + h, z, DARK_LOG);
                c.blob(x + 0.5, g + h + 1, z + 0.5, 4.5, 3, 4.5, hash(i, j, 115) < 0.5 ? DARK_LEAVES : OAK_LEAVES, 0.25);
            }
        }
        if (c.touches(-FLAT - 10, -FLAT - 10, FLAT + 10, FLAT + 10)) temple(c);
    }

    static boolean nearGiant(int x, int z) {
        int ti = Math.floorDiv(x, TREE_CELL), tj = Math.floorDiv(z, TREE_CELL);
        for (int i = ti - 1; i <= ti + 1; i++) {
            for (int j = tj - 1; j <= tj + 1; j++) {
                int[] t = tree(i, j);
                if (t != null && Math.hypot(x - t[0], z - t[1]) < t[2] / 10.0 + 12) return true;
            }
        }
        return false;
    }

    /** One colossal tree: flared trunk, buttress roots, branches and canopy. */
    private static void giantTree(Chunk c, int[] t, int i, int j) {
        double x = t[0] + 0.5, z = t[1] + 0.5, r = t[2] / 10.0;
        int g = ground(t[0], t[1]);
        int top = t[3];
        for (int y = g - 3; y <= top; y++) {
            double flare = 1 + 1.1 * Math.exp(-(y - g) / 7.0);
            double taper = 1 - 0.45 * (y - g) / (double) (top - g);
            c.cylinder(x, z, y, y, Math.max(1.5, r * flare * taper), DARK_LOG);
        }
        // buttress roots
        int roots = 5 + (int) (hash(i, j, 121) * 3);
        for (int k = 0; k < roots; k++) {
            double a = k * Math.PI * 2 / roots + hash(i, j, 122 + k);
            double len = r + 7 + hash(i, j, 130 + k) * 6;
            double ex = x + Math.cos(a) * len, ez = z + Math.sin(a) * len;
            c.tube(x + Math.cos(a) * r, g + 7, z + Math.sin(a) * r, ex, ground((int) ex, (int) ez) - 1, ez, 1.7, DARK_LOG);
        }
        // branches and the canopy
        int branches = 4 + (int) (hash(i, j, 140) * 3);
        for (int k = 0; k < branches; k++) {
            double a = k * Math.PI * 2 / branches + hash(i, j, 141 + k) * 1.2;
            int by = top - 34 + (int) (k * 30.0 / branches);
            double len = 11 + hash(i, j, 150 + k) * 8;
            double ex = x + Math.cos(a) * len, ez = z + Math.sin(a) * len, ey = by + 7;
            c.tube(x, by, z, ex, ey, ez, 1.3, DARK_LOG);
            c.blob(ex, ey + 2, ez, 8 + hash(i, j, 160 + k) * 3, 4, 8 + hash(i, j, 170 + k) * 3, k % 2 == 0 ? DARK_LEAVES : OAK_LEAVES, 0.2);
        }
        c.blob(x, top + 3, z, 13, 6.5, 13, DARK_LEAVES, 0.2);
        c.blob(x + 3, top + 7, z - 2, 8, 4, 8, OAK_LEAVES, 0.25);
    }

    /** The temple clearing. */
    private static void temple(Chunk c) {
        int y = CLEARING;
        pagoda(c, 0, y, 10, 6, 2, PLANKS);
        pagoda(c, -20, y, 8, 3, 1, PLANKS);
        pagoda(c, 20, y, 8, 3, 1, PLANKS);
        torii(c, 0, y, -30, 4, 9);
        bridge(c, 0, y - 1, -21, 0, y - 1, -7, 2);
        for (int k = -42; k <= -24; k += 6) {
            lanternPost(c, -4, y, k);
            lanternPost(c, 4, y, k);
        }
        lanternPost(c, -10, y, -4);
        lanternPost(c, 10, y, -4);
    }
}
