package com.shinobiarts.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.shinobiarts.ninja.SageRealms;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * The Sage realms:
 * <ul>
 *   <li>/realm leave — anyone in a realm goes back to where they came in from.</li>
 *   <li>/realm enter &lt;myoboku|ryuchi|shikkotsu&gt; [players] — operators send players (or themselves) in.</li>
 *   <li>/realm leave &lt;players&gt; — operators send players out.</li>
 * </ul>
 */
public final class RealmCommand {
    private RealmCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("realm")
                .then(Commands.literal("leave")
                        .executes(ctx -> leave(ctx.getSource(), List.of(ctx.getSource().getPlayerOrException())))
                        .then(Commands.argument("players", EntityArgument.players()).requires(s -> s.hasPermission(2))
                                .executes(ctx -> leave(ctx.getSource(), EntityArgument.getPlayers(ctx, "players")))))
                .then(Commands.literal("enter").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("realm", StringArgumentType.word())
                                .suggests((ctx, b) -> SharedSuggestionProvider.suggest(Arrays.stream(SageRealms.Realm.values()).map(r -> r.id), b))
                                .executes(ctx -> enter(ctx, List.of(ctx.getSource().getPlayerOrException())))
                                .then(Commands.argument("players", EntityArgument.players())
                                        .executes(ctx -> enter(ctx, EntityArgument.getPlayers(ctx, "players")))))));
    }

    private static int enter(CommandContext<CommandSourceStack> ctx, Collection<ServerPlayer> players) throws CommandSyntaxException {
        SageRealms.Realm realm = SageRealms.Realm.byId(StringArgumentType.getString(ctx, "realm"));
        if (realm == null) {
            ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.realm_unknown"));
            return 0;
        }
        int n = 0;
        for (ServerPlayer p : players) if (SageRealms.enter(p, realm)) n++;
        if (n == 0) ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.realm_missing"));
        return n;
    }

    private static int leave(CommandSourceStack source, Collection<ServerPlayer> players) {
        int n = 0;
        for (ServerPlayer p : players) if (SageRealms.leave(p)) n++;
        if (n == 0) source.sendFailure(Component.translatable("message.shinobiarts.realm_not_in").withStyle(ChatFormatting.RED));
        return n;
    }
}
