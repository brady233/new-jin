package com.shinobiarts.jutsu;

import com.shinobiarts.fx.Fx;
import com.shinobiarts.ninja.Afflictions;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.util.Scheduler;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * The advanced natures' jutsu (kekkei genkai of two elements, awakened from DNA or a scroll):
 * <ul>
 *   <li>Lava Release (Fire + Earth): Scorching Stream Rock, Quicklime Congealing, Melting Apparition.</li>
 *   <li>Storm Release (Lightning + Water): Laser Circus, and Storm Cloud (the storm-cloud kind of Storm Release).</li>
 *   <li>Boil Release (Fire + Water): Skilled Mist, Unrivalled Strength.</li>
 *   <li>Scorch Release (Fire + Wind): Scorching Sun, Extremely Steaming Murder.</li>
 * </ul>
 */
public final class AdvancedJutsu {
    private AdvancedJutsu() {}

    /** Persistent-data key: until when Unrivalled Strength's boiling chakra lasts (game time). */
    public static final String BOIL_KEY = "shinobiarts.boilUntil";

    private static Vec3 mouth(ServerPlayer p) {
        return p.getEyePosition().add(p.getLookAngle().scale(0.6)).subtract(0, 0.25, 0);
    }

    private static Vec3 hand(ServerPlayer p, float side) {
        Vec3 look = p.getLookAngle();
        Vec3 right = look.cross(new Vec3(0, 1, 0));
        right = right.lengthSqr() < 1e-6 ? new Vec3(1, 0, 0) : right.normalize();
        return p.getEyePosition().add(look.scale(0.7)).add(right.scale(0.35 * side)).subtract(0, 0.45, 0);
    }

    /** Where the player is aiming, up to {@code range} blocks (stopping at a wall). */
    private static Vec3 aim(ServerPlayer p, double range) {
        Vec3 from = p.getEyePosition(), to = from.add(p.getLookAngle().scale(range));
        BlockHitResult hit = p.level().clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        return hit.getType() == HitResult.Type.MISS ? to : hit.getLocation();
    }

    private static void hurt(ServerLevel level, ServerPlayer p, LivingEntity e, float amount) {
        e.invulnerableTime = 0;
        e.hurt(ModDamage.jutsu(level, null, p), amount);
    }

    private static Vec3 away(Vec3 from, LivingEntity e) {
        Vec3 d = e.position().subtract(from);
        d = new Vec3(d.x, 0, d.z);
        return d.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : d.normalize();
    }

    /** Corrosion eats at whatever armour they wear. */
    private static void corrode(LivingEntity e, int amount) {
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack armour = e.getItemBySlot(slot);
            if (!armour.isEmpty() && armour.isDamageableItem()) armour.hurtAndBreak(amount, e, x -> x.broadcastBreakEvent(slot));
        }
    }

    /** Creatures in front of the player (within {@code range}, inside a cone of half-angle given by {@code cos}). */
    private static List<LivingEntity> inFront(ServerPlayer p, double range, double cos) {
        Vec3 eye = p.getEyePosition(), look = p.getLookAngle();
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : JutsuUtil.inRadius(p.serverLevel(), p, eye, range)) {
            if (e == p) continue;
            Vec3 to = e.getBoundingBox().getCenter().subtract(eye);
            if (to.lengthSqr() < 1e-4 || to.normalize().dot(look) >= cos) out.add(e);
        }
        out.sort(Comparator.comparingDouble(e -> e.distanceToSqr(p)));
        return out;
    }

    // ================================================================ Lava Release

    /**
     * Lava Release: Scorching Stream Rock Technique: a volley of molten rocks spat in an arc. Each one burns what it
     * hits and splashes molten rock where it lands.
     */
    public static boolean scorchingStreamRock(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        float dmg = JutsuUtil.dmg(6f);
        LivingEntity target = JutsuUtil.rayTarget(p, 32);
        for (int k = 0; k < 5; k++) {
            int shot = k;
            Scheduler.later(k * 2, () -> {
                if (!p.isAlive()) return;
                Vec3 from = mouth(p);
                Vec3 spread = new Vec3(level.random.nextGaussian(), level.random.nextGaussian() * 0.4, level.random.nextGaussian()).scale(0.06);
                Vec3 dir = p.getLookAngle().add(spread).normalize();
                Vec3 to = target != null && target.isAlive() ? target.getBoundingBox().getCenter().add(spread.scale(20)) : aim(p, 32);
                if (target == null) {
                    Vec3 far = from.add(dir.scale(32));
                    BlockHitResult wall = level.clip(new ClipContext(from, far, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
                    to = wall.getType() == HitResult.Type.MISS ? far : wall.getLocation();
                }
                Vec3 end = to;
                int ticks = MoreJutsu.travel(level, p, from, end, null, 1.5, 1.0, false, false, (e, at) -> {
                    hurt(level, p, e, dmg);
                    e.setSecondsOnFire(5);
                    JutsuUtil.push(e, dir.scale(0.5).add(0, 0.2, 0));
                }, at -> {
                    level.sendParticles(ParticleTypes.LAVA, at.x, at.y, at.z, 8, 0.3, 0.2, 0.3, 0.1);
                    level.sendParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y, at.z, 6, 0.3, 0.3, 0.3, 0.02);
                    for (LivingEntity e : JutsuUtil.inRadius(level, p, at, 1.8)) e.setSecondsOnFire(3);
                    JutsuUtil.sound(level, at, SoundEvents.LAVA_POP, 1.0f, 0.8f);
                }, null);
                Fx.line(level, Fx.Visual.LAVA_ROCK, from, end, 0.5f + (shot % 2) * 0.12f, ticks + 1);
                JutsuUtil.sound(level, from, SoundEvents.BLAZE_SHOOT, 0.8f, 0.6f + shot * 0.05f);
            });
        }
        return true;
    }

    /**
     * Lava Release: Quicklime Congealing Technique: a stream of quicklime sprayed from the mouth that sets solid on
     * whoever it hits, sealing them in a white crust they can't move in. It sets harder on anyone wet.
     */
    public static boolean quicklimeCongealing(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 from = mouth(p);
        LivingEntity target = JutsuUtil.rayTarget(p, 18);
        Vec3 to = target != null ? target.getBoundingBox().getCenter() : aim(p, 18);
        float dmg = JutsuUtil.dmg(6f);
        int ticks = MoreJutsu.travel(level, p, from, to, null, 1.4, 1.6, true, false, (e, at) -> {
            hurt(level, p, e, dmg);
            int hold = e.isInWaterRainOrBubble() ? 100 : 60;
            Afflictions.stun(e, hold, Afflictions.STUN_NONE);
            Fx.on(level, Fx.Visual.LIME_SHELL, e, null, Math.max(e.getBbWidth(), e.getBbHeight() * 0.6f), hold);
            JutsuUtil.sound(level, e.position(), SoundEvents.STONE_PLACE, 1.4f, 0.6f);
            JutsuUtil.sound(level, e.position(), SoundEvents.SAND_PLACE, 1.2f, 0.7f);
        }, at -> level.sendParticles(ParticleTypes.WHITE_ASH, at.x, at.y, at.z, 40, 0.8, 0.5, 0.8, 0.02), null);
        Fx.line(level, Fx.Visual.QUICKLIME, from, to, 1f, ticks + 8);
        JutsuUtil.sound(level, from, SoundEvents.SAND_BREAK, 1.2f, 0.6f);
        JutsuUtil.sound(level, from, SoundEvents.FIRE_EXTINGUISH, 0.8f, 0.8f);
        return true;
    }

    /**
     * Lava Release: Melting Apparition Technique: a torrent of corrosive lava spewed from the mouth floods across the
     * ground in front, melting everything in its path (and the armour on them).
     */
    public static boolean meltingApparition(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        flat = flat.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : flat.normalize();
        Vec3 origin = p.position().add(flat.scale(1.2));
        Vec3 dir = flat;
        float dmg = JutsuUtil.dmg(5f);
        int duration = 60;
        Fx.line(level, Fx.Visual.MELTING_APPARITION, origin, origin.add(dir.scale(16)), 1f, duration);
        JutsuUtil.sound(level, p.position(), SoundEvents.LAVA_AMBIENT, 2.0f, 0.6f);
        JutsuUtil.sound(level, p.position(), SoundEvents.BLAZE_SHOOT, 1.5f, 0.4f);
        Scheduler.repeat(2, 4, duration / 4, i -> {
            float reach = Math.min(16f, 2f + i * 1.6f);
            for (LivingEntity e : JutsuUtil.inRadius(level, p, origin.add(dir.scale(reach / 2)), reach / 2 + 2.5)) {
                if (e == p) continue;
                Vec3 rel = e.position().subtract(origin);
                double along = rel.dot(dir);
                double side = rel.subtract(dir.scale(along)).horizontalDistance();
                if (along < -0.5 || along > reach || side > 1.5 + along * 0.22 || e.getY() > origin.y + 3) continue;
                hurt(level, p, e, dmg);
                e.setSecondsOnFire(4);
                corrode(e, 3);
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 2));
            }
            if (i % 2 == 0) {
                Vec3 at = origin.add(dir.scale(reach));
                level.sendParticles(ParticleTypes.LAVA, at.x, at.y + 0.3, at.z, 6, 1.0, 0.1, 1.0, 0.1);
                JutsuUtil.sound(level, at, SoundEvents.LAVA_POP, 1.0f, 0.7f);
            }
        });
        return true;
    }

    // ================================================================ Storm Release

    /**
     * Storm Release: Laser Circus: a halo of light gathers at the hands and lets loose a spray of beams that bend
     * through the air to chase down everyone in front.
     */
    public static boolean laserCircus(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        List<LivingEntity> targets = inFront(p, 28, 0.45);
        float dmg = JutsuUtil.dmg(5f);
        Fx.on(level, Fx.Visual.LASER_HALO, p, null, 1f, 26);
        JutsuUtil.sound(level, p.position(), SoundEvents.BEACON_POWER_SELECT, 1.2f, 1.8f);
        int beams = 12;
        for (int k = 0; k < beams; k++) {
            int n = k;
            Scheduler.later(6 + k, () -> {
                if (!p.isAlive()) return;
                Vec3 from = hand(p, n % 2 == 0 ? -1 : 1);
                LivingEntity t = targets.isEmpty() ? null : targets.get(n % targets.size());
                if (t != null && !t.isAlive()) t = null;
                Vec3 spread = new Vec3(level.random.nextGaussian(), level.random.nextGaussian() * 0.5, level.random.nextGaussian()).scale(0.18);
                Vec3 to = t != null ? t.getBoundingBox().getCenter() : aim(p, 28).add(spread.scale(18));
                LivingEntity homing = t;
                int ticks = MoreJutsu.travel(level, p, from, to, homing, 2.4, 0.9, false, false, (e, at) -> {
                    hurt(level, p, e, dmg);
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 1));
                }, at -> level.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y, at.z, 8, 0.2, 0.2, 0.2, 0.2), null);
                Fx.send(level, Fx.Visual.LASER_BEAM, from, to, p.getId(), homing == null ? -1 : homing.getId(), 1f + (n % 3) * 0.2f, ticks + 3);
                if (n % 3 == 0) JutsuUtil.sound(level, from, SoundEvents.BEACON_DEACTIVATE, 0.7f, 2.0f);
            });
        }
        return true;
    }

    /**
     * Storm Release: Storm Cloud: a black storm cloud gathers over where the user looks; for six seconds it pours
     * rain and strikes beams of storm chakra down on everything beneath it.
     */
    public static boolean stormCloud(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        LivingEntity target = JutsuUtil.rayTarget(p, 30);
        Vec3 c = target != null ? target.position() : aim(p, 30);
        double ground = MoreJutsu.groundY(level, c);
        Vec3 base = new Vec3(c.x, ground, c.z);
        float radius = 5f;
        int duration = 120;
        float dmg = JutsuUtil.dmg(7f);
        Fx.at(level, Fx.Visual.STORM_CLOUD, base, radius, duration);
        JutsuUtil.sound(level, base, SoundEvents.LIGHTNING_BOLT_THUNDER, 1.0f, 1.3f);
        Scheduler.repeat(20, 15, (duration - 20) / 15, i -> {
            if (!p.isAlive()) return;
            List<LivingEntity> under = new ArrayList<>();
            for (LivingEntity e : JutsuUtil.inRadius(level, p, base.add(0, 2, 0), radius + 1)) {
                if (e != p && Math.abs(e.getX() - base.x) <= radius + 0.5 && Math.abs(e.getZ() - base.z) <= radius + 0.5) under.add(e);
            }
            Vec3 at;
            if (!under.isEmpty()) {
                LivingEntity e = under.get(level.random.nextInt(under.size()));
                at = e.position();
                hurt(level, p, e, dmg);
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 2));
            } else {
                double a = level.random.nextDouble() * Math.PI * 2, r = level.random.nextDouble() * radius;
                at = new Vec3(base.x + Math.cos(a) * r, MoreJutsu.groundY(level, base.add(Math.cos(a) * r, 0, Math.sin(a) * r)), base.z + Math.sin(a) * r);
            }
            Fx.line(level, Fx.Visual.STORM_BEAM, at.add(0, 9, 0), at, 1f, 8);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y + 0.2, at.z, 20, 0.4, 0.1, 0.4, 0.3);
            JutsuUtil.sound(level, at, SoundEvents.LIGHTNING_BOLT_IMPACT, 1.2f, 1.4f);
        });
        return true;
    }

    // ================================================================ Boil Release

    /**
     * Boil Release: Skilled Mist Technique: a cloud of corrosive mist exhaled ahead that hangs there for a while,
     * melting the skin and armour of everyone inside it (the user breathes it without harm).
     */
    public static boolean skilledMist(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 flat = new Vec3(p.getLookAngle().x, 0, p.getLookAngle().z);
        flat = flat.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : flat.normalize();
        Vec3 c = p.position().add(flat.scale(6));
        Vec3 centre = new Vec3(c.x, MoreJutsu.groundY(level, c), c.z);
        float radius = 4.5f;
        int duration = 140;
        float dmg = JutsuUtil.dmg(3f);
        Fx.send(level, Fx.Visual.ACID_MIST, mouth(p), centre, p.getId(), -1, radius, duration);
        JutsuUtil.sound(level, p.position(), SoundEvents.FIRE_EXTINGUISH, 1.5f, 0.5f);
        JutsuUtil.sound(level, p.position(), SoundEvents.BREWING_STAND_BREW, 1.0f, 0.6f);
        Scheduler.repeat(10, 10, duration / 10 - 1, i -> {
            for (LivingEntity e : JutsuUtil.inRadius(level, p, centre.add(0, 1, 0), radius)) {
                if (e == p) continue;
                hurt(level, p, e, dmg);
                corrode(e, 2);
                e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 40, 0));
            }
            if (i % 3 == 0) JutsuUtil.sound(level, centre, SoundEvents.LAVA_EXTINGUISH, 0.6f, 1.4f);
        });
        return true;
    }

    /**
     * Boil Release: Unrivalled Strength: the user's chakra is brought to the boil and vented as steam, for twenty
     * seconds: much stronger and faster, and every punch bursts with a blast of scalding steam.
     */
    public static boolean unrivalledStrength(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        int duration = 400;
        p.getPersistentData().putLong(BOIL_KEY, level.getGameTime() + duration);
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, duration, 2, false, false, true));
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, duration, 1, false, false, true));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, duration, 0, false, false, true));
        p.addEffect(new MobEffectInstance(MobEffects.JUMP, duration, 1, false, false, true));
        Fx.on(level, Fx.Visual.STEAM_ARMOR, p, null, 1f, duration);
        JutsuUtil.sound(level, p.position(), SoundEvents.FIRE_EXTINGUISH, 2.0f, 0.4f);
        JutsuUtil.sound(level, p.position(), SoundEvents.BLAZE_AMBIENT, 1.5f, 0.5f);
        return true;
    }

    /** Whether a player's Unrivalled Strength is on. */
    public static boolean boiling(ServerPlayer p) {
        return p.getPersistentData().getLong(BOIL_KEY) > p.level().getGameTime();
    }

    /** An Unrivalled Strength punch: a burst of steam that scalds and throws the target. Returns the extra damage. */
    public static float steamPunch(ServerPlayer p, LivingEntity target) {
        ServerLevel level = p.serverLevel();
        Vec3 c = target.getBoundingBox().getCenter();
        Vec3 push = away(p.position(), target).scale(1.3).add(0, 0.4, 0);
        Scheduler.later(1, () -> {
            if (target.isAlive()) JutsuUtil.push(target, push);
        });
        level.sendParticles(ParticleTypes.CLOUD, c.x, c.y, c.z, 20, 0.3, 0.3, 0.3, 0.12);
        Fx.line(level, Fx.Visual.STEAM_BURST, c, p.getEyePosition(), 1f, 12);
        JutsuUtil.sound(level, c, SoundEvents.FIRE_EXTINGUISH, 1.2f, 1.2f);
        return JutsuUtil.dmg(5f);
    }

    // ================================================================ Scorch Release

    /**
     * Scorch Release: Scorching Sun: one blazing orb, a little sun of scorch chakra, flies at the target and dries it
     * out where it strikes (it burns, and leaves them weak and slowed).
     */
    public static boolean scorchingSun(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 from = hand(p, 1);
        LivingEntity target = JutsuUtil.rayTarget(p, 30);
        Vec3 to = target != null ? target.getBoundingBox().getCenter() : aim(p, 30);
        float dmg = JutsuUtil.dmg(9f);
        int ticks = MoreJutsu.travel(level, p, from, to, target, 1.3, 1.2, false, false, (e, at) -> scorch(level, p, e, dmg),
                at -> {
                    level.sendParticles(ParticleTypes.CLOUD, at.x, at.y, at.z, 20, 0.5, 0.5, 0.5, 0.05);
                    JutsuUtil.sound(level, at, SoundEvents.FIRE_EXTINGUISH, 1.2f, 0.7f);
                }, null);
        Fx.send(level, Fx.Visual.SCORCH_ORB, from, to, -1, target == null ? -1 : target.getId(), 1f, ticks + 1);
        JutsuUtil.sound(level, from, SoundEvents.BLAZE_SHOOT, 1.0f, 1.4f);
        return true;
    }

    /** A scorch orb striking: the water boils out of the body (steam), leaving it shrivelled and weak. */
    private static void scorch(ServerLevel level, ServerPlayer p, LivingEntity e, float dmg) {
        hurt(level, p, e, dmg);
        e.addEffect(new MobEffectInstance(MobEffects.WITHER, 60, 1));
        e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 1));
        e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
        Fx.on(level, Fx.Visual.STEAM_BURST, e, null, 1.4f, 30);
        Vec3 c = e.getBoundingBox().getCenter();
        level.sendParticles(ParticleTypes.CLOUD, c.x, c.y, c.z, 30, 0.4, 0.6, 0.4, 0.08);
    }

    /** How many suns Extremely Steaming Murder raises, how long they circle, and how fast. */
    private static final int SUNS = 5, SUN_TICKS = 200;
    private static final double SUN_SPIN = 0.09;

    /** How a launched sun is named in its effect: the caster and which sun (never a real entity id). */
    public static int launchTag(int casterId, int sun) {
        return -2 - (casterId * 8 + sun);
    }

    /** Where sun {@code i} of Extremely Steaming Murder is, {@code age} ticks after it began (the client draws them the same way). */
    public static Vec3 sunAt(Vec3 centre, int i, float age) {
        double a = age * SUN_SPIN + i * Math.PI * 2 / SUNS;
        return centre.add(Math.cos(a) * 1.9, 1.3 + Math.sin(age * 0.11 + i) * 0.35, Math.sin(a) * 1.9);
    }

    /**
     * Scorch Release: Extremely Steaming Murder: five blazing suns rise and circle the user. For ten seconds each one
     * flies off at the nearest enemy in turn, and whatever it touches has the water boiled out of its body.
     */
    public static boolean extremelySteamingMurder(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        long start = level.getGameTime();
        float dmg = JutsuUtil.dmg(12f);
        boolean[] gone = new boolean[SUNS];
        // each sun's number rides in the second entity slot (as -2 - i), and a launch names the caster and the sun together
        for (int i = 0; i < SUNS; i++) Fx.send(level, Fx.Visual.SCORCH_ORBIT, p.position(), p.position(), p.getId(), -2 - i, 1f, SUN_TICKS);
        JutsuUtil.sound(level, p.position(), SoundEvents.BLAZE_AMBIENT, 1.5f, 0.6f);
        JutsuUtil.sound(level, p.position(), SoundEvents.BEACON_ACTIVATE, 1.0f, 1.5f);
        Set<Integer> chased = new HashSet<>();
        Scheduler.repeat(20, 16, (SUN_TICKS - 20) / 16, i -> {
            if (!p.isAlive()) return;
            int sun = -1;
            for (int k = 0; k < SUNS; k++) if (!gone[k]) { sun = k; break; }
            if (sun < 0) return;
            LivingEntity target = null;
            for (LivingEntity e : inFront(p, 16, -1.0)) {
                if (!chased.contains(e.getId())) {
                    target = e;
                    break;
                }
            }
            if (target == null) {
                List<LivingEntity> all = inFront(p, 16, -1.0);
                if (all.isEmpty()) return;
                target = all.get(0);
            }
            chased.add(target.getId());
            gone[sun] = true;
            float age = level.getGameTime() - start;
            Vec3 from = sunAt(p.position(), sun, age);
            LivingEntity t = target;
            int ticks = MoreJutsu.travel(level, p, from, t.getBoundingBox().getCenter(), t, 1.1, 1.3, false, false,
                    (e, at) -> scorch(level, p, e, dmg), null, null);
            Fx.send(level, Fx.Visual.SCORCH_LAUNCH, from, t.getBoundingBox().getCenter(), launchTag(p.getId(), sun), t.getId(), 1f, ticks + 1);
            JutsuUtil.sound(level, from, SoundEvents.BLAZE_SHOOT, 1.0f, 1.2f);
        });
        return true;
    }
}
