package com.shinobiarts.registry;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.ExplosiveTagEntity;
import com.shinobiarts.entity.FtgKunaiEntity;
import com.shinobiarts.entity.JutsuProjectile;
import com.shinobiarts.entity.ShadowClone;
import com.shinobiarts.entity.ThrownToolEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ShinobiArts.MODID);

    public static final RegistryObject<EntityType<JutsuProjectile>> JUTSU_PROJECTILE = ENTITIES.register("jutsu_projectile",
            () -> EntityType.Builder.<JutsuProjectile>of(JutsuProjectile::new, MobCategory.MISC)
                    .sized(0.6f, 0.6f)
                    .clientTrackingRange(6)
                    .updateInterval(10)
                    .build(ShinobiArts.id("jutsu_projectile").toString()));

    public static final RegistryObject<EntityType<ThrownToolEntity>> THROWN_TOOL = ENTITIES.register("thrown_tool",
            () -> EntityType.Builder.<ThrownToolEntity>of(ThrownToolEntity::new, MobCategory.MISC)
                    .sized(0.3f, 0.3f)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build(ShinobiArts.id("thrown_tool").toString()));

    public static final RegistryObject<EntityType<FtgKunaiEntity>> FTG_KUNAI = ENTITIES.register("flying_thunder_god_kunai",
            () -> EntityType.Builder.<FtgKunaiEntity>of(FtgKunaiEntity::new, MobCategory.MISC)
                    .sized(0.4f, 0.4f)
                    .clientTrackingRange(8)
                    .updateInterval(20)
                    .build(ShinobiArts.id("flying_thunder_god_kunai").toString()));

    public static final RegistryObject<EntityType<com.shinobiarts.entity.ExplosiveKunaiEntity>> EXPLOSIVE_KUNAI = ENTITIES.register("explosive_kunai",
            () -> EntityType.Builder.<com.shinobiarts.entity.ExplosiveKunaiEntity>of(com.shinobiarts.entity.ExplosiveKunaiEntity::new, MobCategory.MISC)
                    .sized(0.4f, 0.4f).clientTrackingRange(6).updateInterval(20)
                    .build(ShinobiArts.id("explosive_kunai").toString()));
    public static final RegistryObject<EntityType<com.shinobiarts.entity.SmokeBombEntity>> SMOKE_BOMB = ENTITIES.register("smoke_bomb",
            () -> EntityType.Builder.<com.shinobiarts.entity.SmokeBombEntity>of(com.shinobiarts.entity.SmokeBombEntity::new, MobCategory.MISC)
                    .sized(0.3f, 0.3f).clientTrackingRange(4).updateInterval(10)
                    .build(ShinobiArts.id("smoke_bomb").toString()));
    public static final RegistryObject<EntityType<com.shinobiarts.entity.WireTrapEntity>> WIRE_TRAP = ENTITIES.register("wire_trap",
            () -> EntityType.Builder.<com.shinobiarts.entity.WireTrapEntity>of(com.shinobiarts.entity.WireTrapEntity::new, MobCategory.MISC)
                    .sized(0.25f, 0.25f).clientTrackingRange(6).updateInterval(100)
                    .build(ShinobiArts.id("wire_trap").toString()));

    public static final RegistryObject<EntityType<ExplosiveTagEntity>> EXPLOSIVE_TAG = ENTITIES.register("explosive_tag",
            () -> EntityType.Builder.<ExplosiveTagEntity>of(ExplosiveTagEntity::new, MobCategory.MISC)
                    .sized(0.3f, 0.3f)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build(ShinobiArts.id("explosive_tag").toString()));

    public static final RegistryObject<EntityType<com.shinobiarts.entity.EdoTensei>> EDO_TENSEI = ENTITIES.register("edo_tensei",
            () -> EntityType.Builder.<com.shinobiarts.entity.EdoTensei>of(com.shinobiarts.entity.EdoTensei::new, MobCategory.MISC)
                    .sized(0.6f, 1.8f)
                    .clientTrackingRange(10)
                    .build(ShinobiArts.id("edo_tensei").toString()));

    public static final RegistryObject<EntityType<ShadowClone>> SHADOW_CLONE = ENTITIES.register("shadow_clone",
            () -> EntityType.Builder.<ShadowClone>of(ShadowClone::new, MobCategory.MISC)
                    .sized(0.6f, 1.8f)
                    .clientTrackingRange(8)
                    .build(ShinobiArts.id("shadow_clone").toString()));

    public static final RegistryObject<EntityType<com.shinobiarts.entity.NinjaBandit>> NINJA_BANDIT = ENTITIES.register("ninja_bandit",
            () -> EntityType.Builder.<com.shinobiarts.entity.NinjaBandit>of(com.shinobiarts.entity.NinjaBandit::new, MobCategory.MONSTER)
                    .sized(0.6f, 1.8f)
                    .clientTrackingRange(8)
                    .build(ShinobiArts.id("ninja_bandit").toString()));

    public static final RegistryObject<EntityType<com.shinobiarts.entity.SubstitutionLog>> SUBSTITUTION_LOG = ENTITIES.register("substitution_log",
            () -> EntityType.Builder.<com.shinobiarts.entity.SubstitutionLog>of(com.shinobiarts.entity.SubstitutionLog::new, MobCategory.MISC)
                    .sized(0.7f, 0.7f)
                    .clientTrackingRange(6)
                    .updateInterval(4)
                    .build(ShinobiArts.id("substitution_log").toString()));

    /** Rising Spikes: a spike cluster that bursts out of the ground and sinks back (just for show). */
    public static final RegistryObject<EntityType<com.shinobiarts.entity.EarthSpikes>> EARTH_SPIKES = ENTITIES.register("earth_spikes",
            () -> EntityType.Builder.<com.shinobiarts.entity.EarthSpikes>of(com.shinobiarts.entity.EarthSpikes::new, MobCategory.MISC)
                    .sized(0.5f, 0.5f)
                    .clientTrackingRange(8)
                    .updateInterval(20)
                    .noSave()
                    .build(ShinobiArts.id("earth_spikes").toString()));

    /** Majestic Destroyer Flame: the rolling wall of fire (stays where it was cast, never saved). */
    public static final RegistryObject<EntityType<com.shinobiarts.entity.MajesticFlame>> MAJESTIC_FLAME = ENTITIES.register("majestic_flame",
            () -> EntityType.Builder.<com.shinobiarts.entity.MajesticFlame>of(com.shinobiarts.entity.MajesticFlame::new, MobCategory.MISC)
                    .sized(0.5f, 0.5f)
                    .fireImmune()
                    .noSave()
                    .noSummon()
                    .clientTrackingRange(10)
                    .updateInterval(20)
                    .build(ShinobiArts.id("majestic_flame").toString()));

    /** A player's Susanoo (see ninja/Susanoo.java): follows its owner, never saved. */
    public static final RegistryObject<EntityType<com.shinobiarts.entity.SusanooEntity>> SUSANOO = ENTITIES.register("susanoo",
            () -> EntityType.Builder.<com.shinobiarts.entity.SusanooEntity>of(com.shinobiarts.entity.SusanooEntity::new, MobCategory.MISC)
                    .sized(3.0f, 4.3f)
                    .fireImmune()
                    .noSave()
                    .noSummon()
                    .clientTrackingRange(12)
                    .updateInterval(1)
                    .build(ShinobiArts.id("susanoo").toString()));

    private ModEntities() {}
}
