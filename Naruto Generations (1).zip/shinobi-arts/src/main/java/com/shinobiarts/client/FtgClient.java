package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.client.fx.FxDraw;
import com.shinobiarts.ninja.FlyingThunderGod;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.registry.ModItems;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * The Flying Thunder God on the client: your seals drawn in ink on the blocks you marked, a small glowing seal over
 * anyone carrying your mark, and (holding the kunai) a pulsing ring on the mark you're aiming at, to show that
 * right-clicking will take you there. Nobody else sees your marks.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class FtgClient {
    private static final ResourceLocation SEAL = new ResourceLocation(ShinobiArts.MODID, "textures/entity/ftg/seal.png");

    private FtgClient() {}

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) return;
        NinjaData d = ClientNinjaData.get();
        if (!d.isInitialized() || d.ftg.list.isEmpty()) return;
        String dim = mc.level.dimension().location().toString();
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        float t = mc.level.getGameTime() + event.getPartialTick();
        PoseStack ps = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);

        Map<UUID, Entity> targets = new HashMap<>();
        for (FlyingThunderGod.Mark m : d.ftg.list) if (m.kind == FlyingThunderGod.MarkKind.TARGET && m.uuid != null) targets.put(m.uuid, null);
        if (!targets.isEmpty()) {
            for (Entity e : mc.level.entitiesForRendering()) if (targets.containsKey(e.getUUID())) targets.put(e.getUUID(), e);
        }

        VertexConsumer ink = buffers.getBuffer(RenderType.entityTranslucent(SEAL));
        for (FlyingThunderGod.Mark m : d.ftg.list) {
            if (!m.dim.equals(dim)) continue;
            if (m.kind == FlyingThunderGod.MarkKind.SEAL) {
                if (m.pos.distToCenterSqr(cam) > 96 * 96) continue;
                seal(ink, ps, m, LevelRenderer.getLightColor(mc.level, m.pos.relative(m.face)));
            }
        }
        VertexConsumer glow = buffers.getBuffer(RenderType.entityTranslucentEmissive(SEAL));
        for (FlyingThunderGod.Mark m : d.ftg.list) {                // the mark over a marked target's head
            if (m.kind != FlyingThunderGod.MarkKind.TARGET || m.uuid == null) continue;
            Entity e = targets.get(m.uuid);
            if (e == null) continue;
            Vec3 top = e.getPosition(event.getPartialTick()).add(0, e.getBbHeight() + 0.45, 0);
            Vec3 l = new Vec3(camera.getLeftVector()).scale(0.22), u = new Vec3(camera.getUpVector()).scale(0.22);
            float a = 0.7f + 0.2f * Mth.sin(t * 0.2f);
            FxDraw.quad(glow, ps, top.add(l).add(u), top.add(l).subtract(u), top.subtract(l).subtract(u), top.subtract(l).add(u),
                    new FxDraw.Paint(0, 0, 1, 1, 255, 220, 90, Math.round(255 * a)), FxDraw.FULL);
        }

        // holding the kunai: the mark right-clicking would take you to
        boolean holding = player.getMainHandItem().is(ModItems.FLYING_THUNDER_GOD_KUNAI.get())
                || player.getOffhandItem().is(ModItems.FLYING_THUNDER_GOD_KUNAI.get());
        if (holding && !d.isInCombat(mc.level.getGameTime())) {
            FlyingThunderGod.Mark aim = aimed(player, d, targets, event.getPartialTick());
            if (aim != null) {
                Vec3 at = where(aim, targets, event.getPartialTick());
                Vec3 view = at.subtract(cam).normalize();
                float pulse = 0.5f + 0.5f * Mth.sin(t * 0.4f);
                VertexConsumer add = FxDraw.additive(buffers);
                FxDraw.ring(add, ps, at, view, 0.45f + 0.15f * pulse, 0.08f, 32, FxDraw.addColor(0xFFE24A, 0.9f),
                        FxDraw.addColor(0xFFB020, 0.2f), FxDraw.FULL);
                FxDraw.ring(add, ps, at, view, 0.8f + 0.3f * pulse, 0.05f, 32, FxDraw.addColor(0xFFE24A, 0.5f * (1 - pulse)),
                        FxDraw.addColor(0xFFB020, 0f), FxDraw.FULL);
            }
        }
        ps.popPose();
        buffers.endBatch();
    }

    /** The seal written on one face of a block. */
    private static void seal(VertexConsumer vc, PoseStack ps, FlyingThunderGod.Mark m, int light) {
        Direction f = m.face;
        Vec3 n = new Vec3(f.getStepX(), f.getStepY(), f.getStepZ());
        Vec3 c = Vec3.atCenterOf(m.pos).add(n.scale(0.502));
        Vec3 up = f.getAxis() == Direction.Axis.Y ? new Vec3(0, 0, -1) : new Vec3(0, 1, 0);
        Vec3 right = up.cross(n).normalize();
        double h = 0.46;
        Vec3 r = right.scale(h), u = up.scale(h);
        FxDraw.Paint ink = new FxDraw.Paint(0, 0, 1, 1, 255, 255, 255, 235);
        // corners in the order that faces out along the normal; u = 0..1 left to right, v = 0..1 top to bottom
        FxDraw.vertex(vc, ps, c.subtract(r).add(u), ink, 0, 0, light, n);
        FxDraw.vertex(vc, ps, c.subtract(r).subtract(u), ink, 0, 1, light, n);
        FxDraw.vertex(vc, ps, c.add(r).subtract(u), ink, 1, 1, light, n);
        FxDraw.vertex(vc, ps, c.add(r).add(u), ink, 1, 0, light, n);
    }

    private static Vec3 where(FlyingThunderGod.Mark m, Map<UUID, Entity> targets, float partial) {
        if (m.kind == FlyingThunderGod.MarkKind.TARGET && m.uuid != null && targets.get(m.uuid) != null) {
            Entity e = targets.get(m.uuid);
            return e.getPosition(partial).add(0, e.getBbHeight() * 0.6, 0);
        }
        return m.point();
    }

    /** The same choice the server makes (FlyingThunderGod.aimed), from the marks this client knows. */
    @Nullable
    private static FlyingThunderGod.Mark aimed(LocalPlayer p, NinjaData d, Map<UUID, Entity> targets, float partial) {
        String dim = p.level().dimension().location().toString();
        Vec3 eye = p.getEyePosition(partial), look = p.getViewVector(partial);
        double range = com.shinobiarts.Config.i(com.shinobiarts.Config.FTG_AIM_RANGE);
        FlyingThunderGod.Mark best = null;
        double bestCos = -2;
        for (FlyingThunderGod.Mark m : d.ftg.list) {
            if (!m.dim.equals(dim)) continue;
            Vec3 to = where(m, targets, partial).subtract(eye);
            double dist = to.length();
            if (dist < 1.5 || dist > range) continue;
            double threshold = Math.min(Math.cos(Math.toRadians(5)), Math.cos(Math.atan2(1.6, dist)));
            double c = to.normalize().dot(look);
            if (c >= threshold && c > bestCos) {
                best = m;
                bestCos = c;
            }
        }
        return best;
    }
}
