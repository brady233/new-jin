package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Quaternionf;

import java.util.HashSet;
import java.util.Set;

/**
 * Ceiling walking (Chakra Control): a player hanging from a ceiling is drawn upside down, feet on the ceiling, still
 * facing the way they walk. Turned over about the direction they face, so left and right stay where they belong.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class CeilingRender {
    private static final Set<Integer> FLIPPED = new HashSet<>();

    private CeilingRender() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRenderPre(RenderPlayerEvent.Pre event) {
        Player p = event.getEntity();
        if ((ClientEyes.look(p) & SharinganManager.LOOK_CEILING) == 0) return;
        float partial = event.getPartialTick();
        float yaw = Mth.rotLerp(partial, p.yBodyRotO, p.yBodyRot) * Mth.DEG_TO_RAD;
        float fx = -Mth.sin(yaw), fz = Mth.cos(yaw);
        PoseStack ps = event.getPoseStack();
        ps.pushPose();
        ps.translate(0, p.getBbHeight(), 0);
        ps.mulPose(new Quaternionf().rotateAxis((float) Math.PI, fx, 0f, fz));
        FLIPPED.add(p.getId());
    }

    @SubscribeEvent
    public static void onRenderPost(RenderPlayerEvent.Post event) {
        if (FLIPPED.remove(event.getEntity().getId())) event.getPoseStack().popPose();
    }
}
