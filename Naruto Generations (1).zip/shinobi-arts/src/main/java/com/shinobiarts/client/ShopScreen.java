package com.shinobiarts.client;

import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.network.ShopBuyPacket;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.shop.Shop;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

/**
 * The ninja shop (/shop), in the same panel style as the stats and Kage menus: a tab per category (Tools, Explosives,
 * Food, Jutsu Points), a row per thing for sale with its icon, amount and price, and a Buy button (Shift: five at once).
 * Your Ryo is shown in the corner and updates after each purchase.
 */
public class ShopScreen extends Screen {
    private static final int W = 300, H = 222, ROW_Y = 42, ROW_H = 20, ROWS = 8;

    private CompoundTag data;
    private int tab;
    private int left, top;

    public ShopScreen(CompoundTag data) {
        super(Component.translatable("screen.shinobiarts.shop"));
        this.data = data;
    }

    /** From the server: open the shop, or refresh it if it's already open. */
    public static void open(CompoundTag tag) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof ShopScreen open) {
            open.data = tag;
            open.rebuildWidgets();
        } else {
            mc.setScreen(new ShopScreen(tag));
        }
    }

    private record Row(int index, String item, int count, long price) {}

    /** The entries of the current tab, with their index in the server's list. */
    private List<Row> rows() {
        List<Row> out = new ArrayList<>();
        ListTag items = data.getList("Items", Tag.TAG_COMPOUND);
        for (int i = 0; i < items.size(); i++) {
            CompoundTag t = items.getCompound(i);
            if (t.getString("Cat").equals(Shop.CATEGORIES[tab])) out.add(new Row(i, t.getString("Item"), t.getInt("Count"), t.getLong("Price")));
        }
        return out;
    }

    @Override
    protected void init() {
        left = (this.width - W) / 2;
        top = Math.max(16, (this.height - H) / 2);
        int tx = left + 8;
        for (int i = 0; i < Shop.CATEGORIES.length; i++) {
            int t = i;
            Button b = addRenderableWidget(Button.builder(Component.translatable("screen.shinobiarts.shop." + Shop.CATEGORIES[i]), x -> {
                tab = t;
                rebuildWidgets();
            }).bounds(tx + i * 71, top + 20, 69, 16).build());
            b.active = i != tab;
        }
        List<Row> rows = rows();
        for (int i = 0; i < Math.min(ROWS, rows.size()); i++) {
            Row r = rows.get(i);
            addRenderableWidget(Button.builder(Component.translatable("screen.shinobiarts.shop.buy"),
                    b -> ModNetwork.toServer(new ShopBuyPacket(r.index(), hasShiftDown() ? 5 : 1)))
                    .bounds(left + W - 54, top + ROW_Y + i * ROW_H + 1, 46, 16)
                    .tooltip(Tooltip.create(Component.translatable("screen.shinobiarts.shop.buy_tip"))).build());
        }
    }

    private static ItemStack icon(Row r) {
        if (Shop.POINTS.equals(r.item())) return new ItemStack(com.shinobiarts.registry.ModItems.BLANK_SCROLL.get());
        ResourceLocation id = ResourceLocation.tryParse(r.item());
        Item it = id == null ? null : ForgeRegistries.ITEMS.getValue(id);
        return it == null ? ItemStack.EMPTY : new ItemStack(it, r.count());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        StatScreen.panel(g, left, top, W, H);
        int x = left + 8;
        g.drawString(this.font, this.title, x, top + 7, StatScreen.INK, false);
        long ryo = data.getLong("Ryo");
        Component money = Component.translatable("screen.shinobiarts.shop.ryo", PlayerDataManager.formatRyo(ryo));
        g.drawString(this.font, money, left + W - 8 - this.font.width(money), top + 7, 0xFF7A5A12, false);
        if (Shop.CATEGORIES[tab].equals("points")) {
            Component have = Component.translatable("screen.shinobiarts.shop.points_have", data.getInt("Points"));
            g.drawString(this.font, have, left + W - 8 - this.font.width(have), top + H - 14, StatScreen.INK_SOFT, false);
        }
        g.fill(x, top + 39, left + W - 8, top + 40, StatScreen.LINE);
        List<Row> rows = rows();
        if (rows.isEmpty()) {
            Component none = Component.translatable("screen.shinobiarts.shop.empty");
            g.drawString(this.font, none, left + W / 2 - this.font.width(none) / 2, top + 100, StatScreen.INK_SOFT, false);
        }
        for (int i = 0; i < Math.min(ROWS, rows.size()); i++) {
            Row r = rows.get(i);
            int y = top + ROW_Y + i * ROW_H;
            if (i % 2 == 0) g.fill(x - 2, y, left + W - 6, y + ROW_H - 1, 0x10000000);
            ItemStack stack = icon(r);
            g.renderItem(stack, x, y + 1);
            if (!Shop.POINTS.equals(r.item())) g.renderItemDecorations(this.font, stack, x, y + 1);
            Component name = Shop.POINTS.equals(r.item()) ? Component.translatable("screen.shinobiarts.shop.points_item", r.count())
                    : Component.literal(r.count() + " x ").append(stack.getHoverName());
            g.drawString(this.font, this.font.plainSubstrByWidth(name.getString(), 150), x + 22, y + 6, StatScreen.INK, false);
            String price = PlayerDataManager.formatRyo(r.price());
            g.drawString(this.font, price, left + W - 60 - this.font.width(price), y + 6, r.price() <= ryo ? 0xFF7A5A12 : 0xFFA01818, false);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
