package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.EarthSpikes;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Rising Spikes: the spike cluster model pushing up out of the ground, then sinking back into it. */
public class EarthSpikesRenderer extends EntityRenderer<EarthSpikes> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(ShinobiArts.MODID, "textures/entity/earth_spikes.png");
    /** The model's height in blocks (at scale 1). */
    private static final float HEIGHT = 1.94f;

    public EarthSpikesRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0f;
    }

    @Override
    public void render(EarthSpikes entity, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        float age = entity.tickCount + partialTick - entity.getDelay();
        if (age <= 0f) return;
        float rise = Mth.clamp(age / EarthSpikes.RISE, 0f, 1f);
        rise = 1f - (1f - rise) * (1f - rise);                               // bursts up fast, slows at the top
        float sink = Mth.clamp((age - EarthSpikes.RISE - EarthSpikes.STAND) / EarthSpikes.SINK, 0f, 1f);
        float shown = rise * (1f - sink);
        if (shown <= 0f) return;
        float scale = entity.getScale();
        poseStack.pushPose();
        poseStack.translate(0.0, -(1f - shown) * HEIGHT * scale, 0.0);       // the hidden part is under the ground
        poseStack.mulPose(Axis.YP.rotationDegrees(-entity.getYRot()));
        poseStack.scale(scale, scale, scale);
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        for (JutsuMesh.Group g : JutsuMesh.get("earth_spikes")) {
            JutsuMesh.draw(g, poseStack.last(), vc, 1f, 1f, 1f, 1f, packedLight, OverlayTexture.NO_OVERLAY);
        }
        poseStack.popPose();
        super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(EarthSpikes entity) {
        return TEXTURE;
    }
}
