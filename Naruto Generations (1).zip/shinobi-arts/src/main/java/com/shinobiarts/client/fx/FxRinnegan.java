package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.client.fx.FxDraw.Paint;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * The Rinnegan's techniques and Hiding in Ash: Shinra Tensei's sphere of force blasting outward, Bansho Ten'in's
 * ripples dragging the target in, Chibaku Tensei's black core gathering rock into a growing sphere in the sky, and a
 * billowing cloud of glowing ash that goes up in flames.
 */
final class FxRinnegan {
    private FxRinnegan() {}

    /** Shinra Tensei: a clear sphere of force swells out from the caster, with shock rings along the ground. */
    static void shinra(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        Vec3 centre = (e != null ? e.getPosition(c.partial()) : c.fx().a).add(0, 1, 0);
        float age = c.age();
        float t = age / c.fx().ticks;
        float r = c.fx().size * FxDraw.smooth(Math.min(1f, age / 8f)) + 0.5f;
        float fade = 1f - FxDraw.smooth(t);
        VertexConsumer glow = FxDraw.glow(c.buffers());
        FxDraw.sphere(glow, c.ps(), centre, r, 14, 24, FxDraw.color(0xE8ECFF, 0.22f * fade), FxDraw.FULL);
        FxDraw.sphere(glow, c.ps(), centre, r * 0.97f, 14, 24, FxDraw.color(0xFFFFFF, 0.08f * fade), FxDraw.FULL);
        for (int k = 0; k < 3; k++) {
            float rr = r * (1f - k * 0.18f);
            FxDraw.ring(glow, c.ps(), centre.add(0, -0.95, 0), new Vec3(0, 1, 0), rr, 0.6f, 48, FxDraw.color(0xFFFFFF, 0f),
                    FxDraw.color(0xD8DEFF, 0.5f * fade * (1 - k * 0.3f)), FxDraw.FULL);
        }
    }

    /** Bansho Ten'in: rings of force ripple from the caster's hand along the line to the target. */
    static void bansho(FxClient.Ctx c) {
        Entity caster = c.fx().entityA(), target = c.fx().entityB();
        if (caster == null || target == null) return;
        Vec3 hand = FxLightning.hand(caster, c.partial(), true);
        Vec3 to = target.getPosition(c.partial()).add(0, target.getBbHeight() / 2, 0);
        Vec3 dir = to.subtract(hand);
        double len = dir.length();
        if (len < 0.5) return;
        dir = dir.scale(1 / len);
        float age = c.age();
        float fade = 1f - FxDraw.smooth(age / c.fx().ticks);
        VertexConsumer glow = FxDraw.glow(c.buffers());
        for (int k = 0; k < 6; k++) {
            float ph = ((age * 0.12f) + k / 6f) % 1f;                 // ripples running from the target toward the hand
            Vec3 at = to.lerp(hand, ph);
            float rad = 0.35f + (1 - ph) * 0.9f;
            FxDraw.ring(glow, c.ps(), at, dir, rad, 0.1f, 28, FxDraw.color(0xE6D8FF, 0.6f * fade * Mth.sin(ph * Mth.PI)),
                    FxDraw.color(0xB89CFF, 0f), FxDraw.FULL);
        }
        FxDraw.ribbon(FxDraw.additive(c.buffers()), c.ps(), c.cam(), List.of(hand, to), 0.08f, 0f, FxDraw.addColor(0xB89CFF, 0.5f * fade),
                FxDraw.addColor(0xB89CFF, 0.2f * fade), FxDraw.FULL);
    }

    /**
     * Chibaku Tensei: a small black sphere rises slowly into the sky; rocks and chunks of earth tear up out of the
     * ground and fly up to it, packing on layer by layer into a round ball of rock that keeps growing. When it has
     * gathered everything it hangs a moment, then falls and smashes apart on the ground. Follows ChibakuPath, like the
     * server.
     */
    static void chibaku(FxClient.Ctx c) {
        com.shinobiarts.fx.ChibakuPath path = new com.shinobiarts.fx.ChibakuPath(c.fx().a, c.fx().b.y);
        float age = c.age();
        int land = path.landTick();
        Vec3 core = path.core(Math.min(age, land));
        float radius = path.radius(age);
        float crash = Mth.clamp((age - land) / (float) com.shinobiarts.fx.ChibakuPath.CRASH, 0f, 1f);
        if (crash > 0f && age - land < 1.5f) com.shinobiarts.client.CameraShake.from(core, 6f, 90, 45);     // it blows apart: everyone near feels it
        int light = FxDraw.lightAt(core);
        VertexConsumer lit = FxDraw.lit(c.buffers());
        VertexConsumer add = FxDraw.additive(c.buffers());
        if (crash <= 0f) {
            // the black core, glowing faintly, and once rock has gathered a solid round body of stone round it
            FxDraw.sphere(lit, c.ps(), core, 0.55f, 10, 16, FxDraw.color(0x050508, 1f), light);
            FxDraw.billboard(add, c.ps(), c.camera(), core, 3.5f + radius, 3.5f + radius, age * 0.02f, FxDraw.addColor(0x7A5AC8, 0.22f), FxDraw.FULL);
            if (radius > 1.0f) FxDraw.sphere(lit, c.ps(), core, radius * 0.9f, 20, 32, FxDraw.color(0x5E5850, 1f), light);
        } else if (crash < 0.5f) {                                     // the blast
            float f = crash / 0.5f;
            FxDraw.billboard(add, c.ps(), c.camera(), core, 12 + 40 * f, 12 + 40 * f, 0, FxDraw.addColor(0xFFE2B0, 0.9f * (1 - f)), FxDraw.FULL);
            FxDraw.sphere(add, c.ps(), core, radius + 20 * f, 16, 24, FxDraw.addColor(0xFF9A40, 0.5f * (1 - f)), FxDraw.FULL);
        }
        VertexConsumer vc = FxDraw.blocks(c.buffers());
        Paint[] rock = {FxDraw.block("minecraft:block/stone", 0xFFFFFF, 1f), FxDraw.block("minecraft:block/dirt", 0xFFFFFF, 1f),
                FxDraw.block("minecraft:block/cobblestone", 0xFFFFFF, 1f), FxDraw.block("minecraft:block/andesite", 0xFFFFFF, 1f),
                FxDraw.block("minecraft:block/granite", 0xFFFFFF, 1f), FxDraw.block("minecraft:block/gravel", 0xFFFFFF, 1f),
                FxDraw.block("minecraft:block/grass_block_side", 0xFFFFFF, 1f), FxDraw.block("minecraft:block/deepslate", 0xFFFFFF, 1f)};
        RandomSource r = FxDraw.rng(c.fx().seed, 30);
        // a full, dense ball: layer on layer of blocks, each layer an even spread over the sphere, inner layers first
        int layers = 6, n = 0;
        int[] perLayer = new int[layers];
        for (int L = 0; L < layers; L++) {
            float shellR = com.shinobiarts.fx.ChibakuPath.FINAL_RADIUS * (L + 1) / layers;
            perLayer[L] = Math.max(12, Math.round(4 * Mth.PI * shellR * shellR / 0.9f));
            n += perLayer[L];
        }
        double gold = Math.PI * (3 - Math.sqrt(5));
        int k = 0;
        for (int L = 0; L < layers; L++) {
            int m = perLayer[L];
            for (int j = 0; j < m; j++, k++) {
                float order = k / (float) n;
                float start = order * com.shinobiarts.fx.ChibakuPath.RISE * 0.85f + r.nextFloat() * 6f;
                float flight = 22 + r.nextFloat() * 14;
                double yy = 1 - 2 * (j + 0.5) / m;
                double rad = Math.sqrt(1 - yy * yy), th = gold * j + L;
                Vec3 dir = new Vec3(Math.cos(th) * rad, yy, Math.sin(th) * rad);
                float shell = Math.min(path.radius(start + flight), com.shinobiarts.fx.ChibakuPath.FINAL_RADIUS * (L + 1) / layers);
                Vec3 offset = dir.scale(Math.max(0.7, shell - 0.3));
                double gx = c.fx().a.x + r.nextGaussian() * 14, gz = c.fx().a.z + r.nextGaussian() * 14;
                Vec3 from = new Vec3(gx, path.groundY() + 0.3, gz);
                float s = 0.85f + r.nextFloat() * 0.45f;
                float spin = r.nextFloat() * Mth.TWO_PI;
                Paint paint = rock[r.nextInt(rock.length)];
                Vec3 scatter = dir.scale(1.0 + r.nextFloat() * 1.4).add(0, r.nextFloat() * 0.4, 0);
                float t = (age - start) / flight;
                if (t <= 0) continue;
                Vec3 at;
                if (crash > 0f) {                                      // blown apart in every direction
                    float tau = age - land;
                    at = core.add(offset).add(scatter.scale(tau)).subtract(0, 0.02 * tau * tau, 0);
                    s *= 1f - crash * 0.7f;
                    spin += tau * 0.3f;
                } else if (t >= 1) {
                    at = core.add(offset);                             // packed into the ball
                } else {
                    at = from.lerp(core.add(offset), FxDraw.smooth(t)).add(0, Mth.sin(t * Mth.PI) * 3.0, 0);
                    spin += age * 0.15f;
                }
                Vec3 x = new Vec3(Mth.cos(spin), 0, Mth.sin(spin)).scale(s), z = new Vec3(-Mth.sin(spin), 0.3, Mth.cos(spin)).normalize().scale(s);
                FxDraw.box(vc, c.ps(), at, x, new Vec3(0, s * 0.85, 0), z, paint, light);
            }
        }
    }


    /**
     * Hiding in Ash: a thick, rolling cloud of grey ash full of glowing embers; at the end a spark sets the whole of it
     * alight in a rush of flame.
     */
    static void ash(FxClient.Ctx c) {
        Vec3 centre = c.fx().a;
        float age = c.age();
        int ticks = c.fx().ticks;
        float ignite = Mth.clamp((age - (ticks - 10)) / 3f, 0f, 1f);
        float gone = Mth.clamp((age - (ticks - 7)) / 7f, 0f, 1f);
        float fade = Mth.clamp(age / 6f, 0f, 1f) * (1f - gone);
        float radius = c.fx().size;
        VertexConsumer smoke = FxDraw.litTex(c.buffers(), FxYin.PUFF);
        RandomSource r = FxDraw.rng(c.fx().seed, 31);
        int light = FxDraw.lightAt(centre);
        List<Vec3> spots = new ArrayList<>();
        for (int k = 0; k < 48; k++) {
            Vec3 d = new Vec3(r.nextGaussian(), r.nextGaussian() * 0.5, r.nextGaussian()).normalize().scale(r.nextFloat() * radius);
            Vec3 p = centre.add(d).add(0, 0.25 * Mth.sin(age * 0.05f + k), 0);
            spots.add(p);
            float s = 1.8f + r.nextFloat() * 1.8f;
            int g = 68 + r.nextInt(30);
            int rr = Math.round(Mth.lerp(ignite, g, 255)), gg = Math.round(Mth.lerp(ignite, g - 4, 140)), bb = Math.round(Mth.lerp(ignite, g - 8, 40));
            FxDraw.billboard(smoke, c.ps(), c.camera(), p, s, s, r.nextFloat() * 6 + age * 0.01f, new Paint(0, 0, 1, 1, rr, gg, bb,
                    Math.round(210 * fade)), ignite > 0 ? FxDraw.FULL : light);
        }
        VertexConsumer add = FxDraw.additive(c.buffers());
        for (int k = 0; k < 40; k++) {                               // embers drifting in it
            Vec3 p = spots.get(k % spots.size()).add(r.nextGaussian() * 0.5, ((age * 0.03f + r.nextFloat()) % 1f) * 1.2f, r.nextGaussian() * 0.5);
            float flicker = 0.5f + 0.5f * Mth.sin(age * 0.7f + k);
            FxDraw.billboard(add, c.ps(), c.camera(), p, 0.09f, 0.09f, 0, FxDraw.addColor(0xFF7A20, (0.4f + 0.6f * flicker) * fade), FxDraw.FULL);
        }
        if (ignite > 0) {                                            // it all goes up
            for (Vec3 p : spots) {
                FxDraw.billboard(add, c.ps(), c.camera(), p, 2.6f, 2.6f, 0, FxDraw.addColor(0xFF8A30, 0.5f * ignite * (1 - gone)), FxDraw.FULL);
            }
        }
    }

    // ---------------------------------------------------------------- Tengai Shinsei

    private static final net.minecraft.resources.ResourceLocation METEOR_ROCK =
            new net.minecraft.resources.ResourceLocation(com.shinobiarts.ShinobiArts.MODID, "textures/entity/rinnegan/meteor.png");

    /** How far a meteor's surface sits out from its round shape in direction {@code d}: lumpy, the same every frame. */
    private static float lump(Vec3 d, long seed) {
        RandomSource r = RandomSource.create(seed);
        float out = 1f;
        for (int k = 0; k < 7; k++) {
            Vec3 axis = new Vec3(r.nextGaussian(), r.nextGaussian(), r.nextGaussian()).normalize();
            float f = 1.5f + k * 0.9f;
            out += (0.24f / (1 + k * 0.5f)) * Mth.sin((float) (d.dot(axis) * f) * 3f + r.nextFloat() * 6f);
        }
        return out;
    }

    /**
     * Tengai Shinsei, falling (a = where it starts high in the sky, b = where it lands, size = its radius): a huge
     * lumpy rock tumbling slowly, its leading face white-hot, a long trail of fire and black smoke behind it, and
     * its shadow spreading over the ground below as it comes.
     */
    static void meteor(FxClient.Ctx c) {
        Vec3 a = c.fx().a, b = c.fx().b;
        float p = Mth.clamp(c.age() / c.fx().ticks, 0f, 1f), R = c.fx().size;
        Vec3 dir = b.subtract(a);
        if (dir.lengthSqr() < 1e-6) return;
        dir = dir.normalize();
        Vec3 pos = a.lerp(b, p);
        long seed = c.fx().seed;
        float spin = c.age() * 0.012f;
        Vec3 ax = FxDraw.perpendicular(dir), bx = dir.cross(ax);

        // the rock
        VertexConsumer rock = c.buffers().getBuffer(net.minecraft.client.renderer.RenderType.entityCutoutNoCull(METEOR_ROCK));
        VertexConsumer add = FxDraw.additive(c.buffers());
        int lat = 20, lon = 32;
        Paint stone = new Paint(0, 0, 1, 1, 255, 235, 225, 255);
        for (int i = 0; i < lat; i++) {
            for (int j = 0; j < lon; j++) {
                Vec3[] q = new Vec3[4];
                Vec3[] n = new Vec3[4];
                float[][] uv = {{j, i}, {j, i + 1}, {j + 1, i + 1}, {j + 1, i}};
                for (int k = 0; k < 4; k++) {
                    float th = Mth.PI * uv[k][1] / lat, ph = Mth.TWO_PI * uv[k][0] / lon + spin;
                    Vec3 d = ax.scale(Mth.sin(th) * Mth.cos(ph)).add(bx.scale(Mth.sin(th) * Mth.sin(ph))).add(dir.scale(Mth.cos(th)));
                    n[k] = d;
                    q[k] = pos.add(d.scale(R * lump(d, seed)));
                }
                for (int k = 0; k < 4; k++) FxDraw.vertex(rock, c.ps(), q[k], stone, uv[k][0] * 3f / lon, uv[k][1] * 1.5f / lat, FxDraw.FULL, n[k]);
                for (int k = 0; k < 4; k++) {                    // the face it's falling into, white-hot
                    float heat = (float) Math.max(0, n[k].dot(dir));
                    heat = heat * heat;
                    Paint hot = new Paint(0.25f, 0.25f, 0.75f, 0.75f, Math.round(255 * heat), Math.round(150 * heat * heat), Math.round(40 * heat * heat * heat), 255);
                    FxDraw.vertex(add, c.ps(), pos.add(n[k].scale(R * lump(n[k], seed) * 1.06f)), hot, 0, 0, FxDraw.FULL, n[k]);
                }
            }
        }
        FxDraw.sphere(add, c.ps(), pos.add(dir.scale(R * 0.55)), R * 1.15f, 10, 14, FxDraw.addColor(0xFF7A20, 0.18f), FxDraw.FULL);
        if (p > 0.97f) com.shinobiarts.client.CameraShake.from(b, 7f * Math.min(2f, R / 7f), 120, 60);   // it's about to land

        // fire and smoke streaming behind it
        RandomSource r = FxDraw.rng(seed, 40);
        VertexConsumer smoke = FxDraw.lit(c.buffers());
        for (int k = 0; k < 7; k++) {
            Vec3 off = ax.scale((r.nextFloat() - 0.5) * R * 1.2).add(bx.scale((r.nextFloat() - 0.5) * R * 1.2));
            float len = R * (11 + r.nextFloat() * 7);
            float wob = c.age() * 0.3f + k;
            List<Vec3> fire = new ArrayList<>();
            for (int i = 0; i <= 8; i++) {
                float s = i / 8f;
                Vec3 sway = ax.scale(Mth.sin(wob + s * 4) * R * 0.25 * s).add(bx.scale(Mth.cos(wob * 0.8f + s * 3) * R * 0.25 * s));
                fire.add(pos.add(off.scale(1 - s * 0.3)).subtract(dir.scale(len * (1 - s))).add(sway.scale(1 - s)));
            }
            FxDraw.ribbon(add, c.ps(), c.cam(), fire, R * 1.6f, 0.15f, FxDraw.addColor(0xA01A00, 0f), FxDraw.addColor(k % 2 == 0 ? 0xFFB040 : 0xFF6A10, 0.75f), FxDraw.FULL);
            List<Vec3> trail = new ArrayList<>();
            for (int i = 0; i <= 8; i++) {
                float s = i / 8f;
                trail.add(pos.add(off).subtract(dir.scale(len * 2.2f * (1 - s) + R)).add(0, (1 - s) * R * 0.6, 0));
            }
            FxDraw.ribbon(smoke, c.ps(), c.cam(), trail, R * 2.4f, 0.4f, FxDraw.color(0x1A1614, 0f), FxDraw.color(0x2A2420, 0.55f), FxDraw.lightAt(pos));
        }

        // its shadow on the ground, and the glow of it as it nears
        double gy = FxDraw.groundY(b) + 0.06;
        Vec3 g = new Vec3(b.x, gy, b.z);
        float shade = FxDraw.smooth(p);
        FxDraw.ring(smoke, c.ps(), g, new Vec3(0, 1, 0), R * (0.6f + 1.2f * shade) / 2, R * (0.6f + 1.2f * shade), 40,
                FxDraw.color(0x000000, 0.55f * shade), FxDraw.color(0x000000, 0f), FxDraw.lightAt(g.add(0, 1, 0)));
        if (p > 0.6f) {
            float hot = (p - 0.6f) / 0.4f;
            FxDraw.ring(add, c.ps(), g.add(0, 0.02, 0), new Vec3(0, 1, 0), R * 1.2f, R * 2.4f, 40, FxDraw.addColor(0xFF6A10, 0.5f * hot),
                    FxDraw.addColor(0xFF6A10, 0f), FxDraw.FULL);
        }
    }

    /**
     * A meteor landing (a = where, size = the blast's radius): a white flash, a fireball swelling out of the ground,
     * a dome of dust and a shockwave racing across the ground, and rubble thrown up and falling back.
     */
    static void meteorImpact(FxClient.Ctx c) {
        Vec3 o = c.fx().a;
        float age = c.age(), p = c.progress(), R = c.fx().size;
        double gy = FxDraw.groundY(o.add(0, 1, 0)) + 0.05;
        Vec3 g = new Vec3(o.x, gy, o.z);
        VertexConsumer add = FxDraw.additive(c.buffers());
        VertexConsumer dust = FxDraw.lit(c.buffers());
        int light = FxDraw.lightAt(g.add(0, 2, 0));
        float flash = Mth.clamp(1f - age / 6f, 0f, 1f);
        if (flash > 0) FxDraw.sphere(add, c.ps(), g, R * (0.3f + 0.5f * (1 - flash)), 10, 16, FxDraw.addColor(0xFFFFFF, flash), FxDraw.FULL);
        float fb = FxDraw.smooth(Math.min(1f, age / 12f));
        float fbFade = 1f - FxDraw.smooth(Math.max(0f, (age - 8f) / 20f));
        FxDraw.sphere(add, c.ps(), g, R * 0.65f * fb, 10, 16, FxDraw.addColor(0xFF7A20, 0.8f * fbFade), FxDraw.FULL);
        FxDraw.sphere(add, c.ps(), g, R * 0.4f * fb, 10, 16, FxDraw.addColor(0xFFD070, 0.8f * fbFade), FxDraw.FULL);
        float dome = FxDraw.smooth(Math.min(1f, age / 25f));
        FxDraw.sphere(dust, c.ps(), g, R * (0.4f + 0.8f * dome), 10, 18, FxDraw.color(0x6A5A48, 0.55f * (1 - p)), light);
        for (int k = 0; k < 3; k++) {                          // shockwaves across the ground
            float t = Mth.clamp((age - k * 4f) / 22f, 0f, 1f);
            if (t <= 0 || t >= 1) continue;
            FxDraw.ring(add, c.ps(), g.add(0, 0.1 + k * 0.05, 0), new Vec3(0, 1, 0), R * (0.3f + 2.2f * t), R * 0.18f * (1 - t) + 0.3f, 64,
                    FxDraw.addColor(0xFFE0B0, 0.7f * (1 - t)), FxDraw.addColor(0xFF7A20, 0f), FxDraw.FULL);
            FxDraw.ring(dust, c.ps(), g.add(0, 0.08, 0), new Vec3(0, 1, 0), R * (0.25f + 2.0f * t), R * 0.4f, 64,
                    FxDraw.color(0x5A4C3E, 0.5f * (1 - t)), FxDraw.color(0x5A4C3E, 0f), light);
        }
        RandomSource r = FxDraw.rng(c.fx().seed, 50);
        VertexConsumer rock = c.buffers().getBuffer(net.minecraft.client.renderer.RenderType.entityCutoutNoCull(METEOR_ROCK));
        Paint stone = new Paint(0, 0, 1, 1, 200, 180, 165, 255);
        for (int k = 0; k < 40; k++) {                          // rubble flung up, falling back
            float ang = r.nextFloat() * Mth.TWO_PI, speed = 0.25f + r.nextFloat() * 0.6f, up = 0.6f + r.nextFloat() * 0.9f;
            float t = age;
            Vec3 at = g.add(Mth.cos(ang) * speed * t * R * 0.12, Math.max(0, up * t * R * 0.08 - 0.04 * t * t), Mth.sin(ang) * speed * t * R * 0.12);
            if (at.y <= gy && t > 4) continue;
            float s = 0.25f + r.nextFloat() * 0.6f;
            float rot = t * (0.1f + r.nextFloat() * 0.3f);
            Vec3 x = new Vec3(Mth.cos(rot), Mth.sin(rot), 0).scale(s), y = new Vec3(-Mth.sin(rot), Mth.cos(rot), 0).scale(s * 0.8), z = new Vec3(0, 0, s * 0.9);
            FxDraw.box(rock, c.ps(), at, x, y, z, stone, light);
        }
    }
}
