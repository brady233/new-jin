package com.shinobiarts.client;

import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.Susanoo;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/**
 * The Susanoo's health bar at the top of the screen (its stage, health, Amaterasu burning, blocking and the special's
 * cooldown), the summon cooldown after it's gone, and a faint crystal tint at the screen's edges while you ride in
 * the Perfect Susanoo's forehead (first person).
 */
public final class SusanooHud {
    private SusanooHud() {}

    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, width, height) -> render(g, width, height);

    private static void render(GuiGraphics g, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.options.hideGui) return;
        NinjaData d = ClientNinjaData.get();
        if (!d.isInitialized()) return;
        Font font = mc.font;
        long now = player.level().getGameTime();
        int stage = d.getSusanooStage();
        int chakra = d.getSusanooColors()[4] & 0xFFFFFF;
        if (stage == 0) {
            long cd = d.cooldownRemaining("susanoo", now);
            if (cd > 0 && d.isMangekyouActive()) {
                Component text = Component.translatable("hud.shinobiarts.susanoo_cooldown", (cd + 19) / 20);
                g.drawString(font, text, (width - font.width(text)) / 2, 6, 0xFF9A9AB0, true);
            }
            return;
        }
        if (stage == 5 && mc.options.getCameraType().isFirstPerson()) crystal(g, width, height, chakra);

        int w = 182, x = (width - w) / 2, y = 16;
        Component title = Component.translatable("hud.shinobiarts.susanoo", Susanoo.stageName(stage));
        g.drawString(font, title, (width - font.width(title)) / 2, y - 11, 0xFF000000 | brighten(chakra), true);
        float max = Math.max(1, d.getSusanooMaxHp()), hp = Math.max(0, Math.min(max, d.getSusanooHp()));
        g.fill(x - 1, y - 1, x + w + 1, y + 6, 0xC0000000);
        int fill = Math.round(w * hp / max);
        g.fillGradient(x, y, x + fill, y + 5, 0xFF000000 | brighten(chakra), 0xFF000000 | chakra);
        boolean burning = d.getSusanooBurnUntil() > now;
        if (burning && (now / 4) % 2 == 0) g.fill(x, y, x + fill, y + 5, 0x90100014);   // Amaterasu flickering over it
        String nums = (int) Math.ceil(hp) + " / " + (int) max;
        g.drawString(font, nums, (width - font.width(nums)) / 2, y + 8, 0xFFE8E8F0, true);

        int tagY = y + 19;
        StringBuilder tags = new StringBuilder();
        if (burning) tags.append(Component.translatable("hud.shinobiarts.susanoo_burning").getString()).append("   ");
        if (player.isShiftKeyDown()) tags.append(Component.translatable("hud.shinobiarts.susanoo_blocking").getString()).append("   ");
        long special = d.cooldownRemaining("susanoo_special", now);
        if (stage >= 2 && special > 0) {
            tags.append(Component.translatable("hud.shinobiarts.susanoo_special", String.format("%.1f", special / 20.0)).getString());
        }
        if (tags.length() > 0) {
            String s = tags.toString().trim();
            g.drawString(font, s, (width - font.width(s)) / 2, tagY, burning ? 0xFFB070FF : 0xFFB0B0C8, true);
        }
    }

    private static int brighten(int c) {
        int r = (c >> 16) & 255, gr = (c >> 8) & 255, b = c & 255;
        return (Math.min(255, r + (255 - r) / 3) << 16) | (Math.min(255, gr + (255 - gr) / 3) << 8) | Math.min(255, b + (255 - b) / 3);
    }

    /** A faint tint toward the screen's edges: you're looking out through the forehead crystal. */
    private static void crystal(GuiGraphics g, int width, int height, int color) {
        int band = Math.max(8, Math.min(width, height) / 6);
        int c = color & 0xFFFFFF;
        g.fillGradient(0, 0, width, band, 0x50000000 | c, c);
        g.fillGradient(0, height - band, width, height, c, 0x50000000 | c);
        int strips = 12;
        for (int i = 0; i < strips; i++) {
            int a = (int) (0x50 * (1 - i / (float) strips));
            int w = Math.max(1, band / strips);
            g.fill(i * w, 0, (i + 1) * w, height, (a << 24) | c);
            g.fill(width - (i + 1) * w, 0, width - i * w, height, (a << 24) | c);
        }
    }
}
