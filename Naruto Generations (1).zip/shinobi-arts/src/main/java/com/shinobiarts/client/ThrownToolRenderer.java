package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.shinobiarts.entity.ThrownToolEntity;
import com.shinobiarts.registry.ModItems;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/**
 * Renders a thrown kunai pointing tip-first along its flight path (like an arrow),
 * and a thrown shuriken lying flat and spinning.
 */
public class ThrownToolRenderer extends EntityRenderer<ThrownToolEntity> {
    private final ItemRenderer itemRenderer;

    public ThrownToolRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.itemRenderer = context.getItemRenderer();
    }

    @Override
    public void render(ThrownToolEntity entity, float entityYaw, float partialTicks, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        if (entity.tickCount < 2 && this.entityRenderDispatcher.camera.getEntity().distanceToSqr(entity) < 12.25) return;
        ItemStack stack = entity.getItem();
        poseStack.pushPose();
        poseStack.translate(0, entity.getBbHeight() / 2, 0);
        if (stack.is(ModItems.SHURIKEN.get())) {
            poseStack.mulPose(Axis.YP.rotationDegrees((entity.tickCount + partialTicks) * 40f));
            poseStack.mulPose(Axis.XP.rotationDegrees(90f));
            poseStack.scale(0.6f, 0.6f, 0.6f);
        } else {
            // Same orientation maths as arrows: afterwards +X points along the flight direction.
            poseStack.mulPose(Axis.YP.rotationDegrees(Mth.lerp(partialTicks, entity.yRotO, entity.getYRot()) - 90.0f));
            poseStack.mulPose(Axis.ZP.rotationDegrees(Mth.lerp(partialTicks, entity.xRotO, entity.getXRot())));
            // The kunai model points diagonally (like an item sprite); turn it so the tip leads.
            poseStack.mulPose(Axis.ZP.rotationDegrees(-45f));
            poseStack.scale(0.55f, 0.55f, 0.55f);
        }
        this.itemRenderer.renderStatic(stack, ItemDisplayContext.NONE, packedLight, OverlayTexture.NO_OVERLAY,
                poseStack, buffer, entity.level(), entity.getId());
        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(ThrownToolEntity entity) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
