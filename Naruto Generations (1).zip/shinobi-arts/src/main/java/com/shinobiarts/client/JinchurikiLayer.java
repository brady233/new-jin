package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.client.fx.FxDraw;
import com.shinobiarts.ninja.Jinchuriki;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.ninja.TailedBeast;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * A jinchuriki's tailed beast chakra, on anyone in a form (the mod's own designs):
 * <ul>
 *   <li>Rage, 1 to 3 tails (Version 1): a boiling, see-through shroud of the beast's chakra, glowing white eyes, its
 *       ears or horns and as many long chakra tails as the form has, sweeping out behind and swaying.</li>
 *   <li>Rage, 4 and 5 tails (Version 2): the shroud turns near-black and thick, glowing veins of the beast's colour
 *       crawling through it, a white glare for eyes and a glowing grin, claws on the hands, darker tails.</li>
 *   <li>Rage, 6 tails (the skeleton): the beast's bones form round the Version 2 shroud: a horned skull with burning
 *       sockets and a jaw full of fangs, a ribcage, spine and shoulder blades, bone down the arms ending in talons,
 *       and every tail a chain of glowing vertebrae with spines.</li>
 *   <li>Chakra cloak: a bright, burning cloak of the beast's colour with dark markings, every one of its tails and eyes
 *       of its colour.</li>
 * </ul>
 */
public class JinchurikiLayer<T extends LivingEntity, M extends HumanoidModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation SHROUD = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jinchuriki/shroud.png");
    private static final ResourceLocation SHROUD_DARK = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jinchuriki/shroud_dark.png");
    private static final ResourceLocation CLOAK = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jinchuriki/cloak.png");
    private static final int BONE = 0xEFE7D2, BONE_SHADE = 0xBFB49A;
    private final HumanoidModel<T> inner, outer;

    public JinchurikiLayer(RenderLayerParent<T, M> parent, EntityModelSet models) {
        super(parent);
        this.inner = new HumanoidModel<>(models.bakeLayer(ClientSetup.SHROUD_INNER_LAYER));
        this.outer = new HumanoidModel<>(models.bakeLayer(ClientSetup.SHROUD_OUTER_LAYER));
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, T entity, float limbSwing, float limbSwingAmount,
                       float partial, float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity.isInvisible()) return;
        int look = ClientEyes.look(entity);
        TailedBeast beast = TailedBeast.byTails(SharinganManager.lookBeast(look));
        int form = SharinganManager.lookBeastForm(look);
        if (beast == null || form == Jinchuriki.NONE) return;
        boolean cloak = form == Jinchuriki.CLOAK;
        boolean dark = !cloak && form >= 4;
        boolean skeleton = !cloak && form >= 6;
        int tails = cloak ? beast.tails : Math.min(form, beast.tails);
        float t = ageInTicks;

        getParentModel().copyPropertiesTo(inner);
        getParentModel().copyPropertiesTo(outer);
        inner.setAllVisible(true);
        outer.setAllVisible(true);
        float[] c = rgb(beast.color), d = rgb(beast.dark);
        float pulse = 0.85f + 0.15f * Mth.sin(t * 0.3f);

        // the shroud itself
        if (cloak) {
            inner.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucentEmissive(CLOAK)), LightTexture.FULL_BRIGHT,
                    OverlayTexture.NO_OVERLAY, lift(c[0]), lift(c[1]), lift(c[2]), 0.82f);
        } else if (dark) {
            // near-black body; the veins in the texture take the beast's colour and glow
            inner.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucentEmissive(SHROUD_DARK)), LightTexture.FULL_BRIGHT,
                    OverlayTexture.NO_OVERLAY, lift(c[0]) * pulse, lift(c[1]) * pulse, lift(c[2]) * pulse, 0.93f);
        } else {
            inner.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucentEmissive(SHROUD)), LightTexture.FULL_BRIGHT,
                    OverlayTexture.NO_OVERLAY, c[0], c[1], c[2], 0.45f);
        }
        // the chakra boiling off it
        float k = (dark ? 0.5f : cloak ? 0.45f : 0.6f) * pulse;
        VertexConsumer swirl = buffers.getBuffer(RenderType.energySwirl(dark ? SHROUD_DARK : SHROUD, (t * 0.011f) % 1f, (-t * 0.035f) % 1f));
        outer.renderToBuffer(ps, swirl, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, c[0] * k, c[1] * k, c[2] * k, 1f);

        VertexConsumer glow = FxDraw.glow(buffers);
        FxDraw.Paint body = dark ? FxDraw.color(0x0C0A0A, 0.95f) : FxDraw.color(cloak ? brighten(beast.color) : beast.color, cloak ? 0.85f : 0.62f);
        FxDraw.Paint edge = FxDraw.color(beast.color, dark ? 0.42f : 0.25f);
        FxDraw.Paint bone = FxDraw.color(BONE, 1f), boneShade = FxDraw.color(BONE_SHADE, 1f), boneGlow = FxDraw.color(beast.color, 0.35f);

        // the tails, from the small of the back
        ps.pushPose();
        getParentModel().body.translateAndRotate(ps);
        float len = cloak ? 2.0f : skeleton ? 2.3f : dark ? 2.0f : 1.5f + 0.12f * tails;
        float base = (beast == TailedBeast.KURAMA ? 0.16f : 0.13f) * (dark ? 1.15f : 1f);
        for (int i = 0; i < tails; i++) {
            List<Vec3> pts = tailPath(i, tails, len, t);
            int n = pts.size() - 1;
            float[] radii = new float[n + 1], halo = new float[n + 1];
            for (int j = 0; j <= n; j++) {
                float s = j / (float) n;
                // thick near the root, a little fuller a third of the way out, then drawn to a fine point
                float r = base * (0.85f + 0.45f * Mth.sin(Mth.PI * Math.min(1f, s * 1.5f))) * (float) Math.pow(1 - s, 0.85) + 0.012f;
                radii[j] = r;
                halo[j] = r * 1.4f + 0.02f;
            }
            if (skeleton) {
                FxDraw.tube(glow, ps, pts, halo, 8, edge, 1f, LightTexture.FULL_BRIGHT, false);
                vertebrae(glow, ps, pts, radii, bone, boneShade);
            } else {
                FxDraw.tube(glow, ps, pts, radii, 10, body, 1f, LightTexture.FULL_BRIGHT, true);
                FxDraw.tube(glow, ps, pts, halo, 10, edge, 1f, LightTexture.FULL_BRIGHT, false);
            }
        }
        if (skeleton) torsoBones(glow, ps, bone, boneShade, boneGlow, t);
        ps.popPose();

        // claws (Version 2 and the skeleton), and the arm bones
        if (dark) {
            for (int side = 0; side < 2; side++) {
                ps.pushPose();
                (side == 0 ? getParentModel().rightArm : getParentModel().leftArm).translateAndRotate(ps);
                float sx = side == 0 ? -1f : 1f;
                if (skeleton) {
                    FxDraw.tube(glow, ps, List.of(new Vec3(sx * 0.05, -0.08, 0), new Vec3(sx * 0.06, 0.28, 0.02), new Vec3(sx * 0.05, 0.6, 0)),
                            new float[]{0.07f, 0.05f, 0.06f}, 8, bone, 1f, LightTexture.FULL_BRIGHT, true);
                    FxDraw.sphere(glow, ps, new Vec3(sx * 0.06, -0.08, 0), 0.13f, 6, 8, boneShade, LightTexture.FULL_BRIGHT);   // shoulder
                    FxDraw.sphere(glow, ps, new Vec3(sx * 0.06, 0.28, 0.02), 0.08f, 6, 8, boneShade, LightTexture.FULL_BRIGHT);  // elbow
                }
                FxDraw.Paint claw = skeleton ? bone : FxDraw.color(beast.color, 0.9f);
                for (int f = -1; f <= 1; f++) {
                    FxDraw.cone(glow, ps, new Vec3(sx * 0.02 + f * 0.07, 0.66, -0.07), new Vec3(sx * 0.02 + f * 0.09, 0.9, -0.22), 0.035f, 6, claw,
                            LightTexture.FULL_BRIGHT);
                }
                ps.popPose();
            }
        }

        // the head: ears or horns (bone for the skeleton), the skull, and the eyes
        ps.pushPose();
        getParentModel().head.translateAndRotate(ps);
        head(glow, ps, beast.head, skeleton ? bone : body, skeleton ? boneGlow : edge, t);
        if (skeleton) skull(glow, ps, bone, boneShade, t);
        FxDraw.Paint eye = cloak ? FxDraw.color(brighten(beast.color), 1f) : skeleton ? FxDraw.color(brighten(beast.color), 1f) : FxDraw.color(0xFFFFFF, 1f);
        float z = skeleton ? -0.36f : -0.312f;
        float open = blink(entity.getId(), t);
        if (open > 0.06f) {                                  // shut tight for a moment while it blinks
            for (int sx = -1; sx <= 1; sx += 2) {
                float x0 = sx * 0.06f, x1 = sx * 0.2f;
                float mi = -0.225f, mo = -0.27f;              // the eye closes onto its middle line
                FxDraw.quad(glow, ps, new Vec3(x0, mi + (-0.24f - mi) * open, z), new Vec3(x1, mo + (-0.29f - mo) * open, z),
                        new Vec3(x1, mo + (-0.25f - mo) * open, z), new Vec3(x0, mi + (-0.21f - mi) * open, z), eye, LightTexture.FULL_BRIGHT);
            }
        }
        if (dark && !skeleton) {                             // Version 2's glowing grin
            FxDraw.Paint grin = FxDraw.color(0xFFFFFF, 0.95f);
            FxDraw.quad(glow, ps, new Vec3(-0.18, -0.1, z), new Vec3(0.18, -0.1, z), new Vec3(0.13, -0.065, z), new Vec3(-0.13, -0.065, z),
                    grin, LightTexture.FULL_BRIGHT);
        }
        ps.popPose();
    }

    /**
     * One tail's path in body space (y down, +z behind): out of the small of the back, back and a little down first,
     * then sweeping up in a long curve, fanned out round the back with the others (two rows when there are many),
     * swaying like flame.
     */
    private static List<Vec3> tailPath(int i, int tails, float len, float t) {
        float spread = Math.min(2.7f, 0.42f * tails);
        float a = tails == 1 ? 0f : (i / (float) (tails - 1) - 0.5f) * spread;
        float lift = tails > 5 && i % 2 == 1 ? 0.18f : 0f;              // every other tail a little higher when there are many
        float phase = t * 0.11f + i * 1.9f;
        Vec3 root = new Vec3(Mth.sin(a) * 0.05, 0.64, 0.14);
        List<Vec3> pts = new ArrayList<>();
        int n = 16;
        for (int j = 0; j <= n; j++) {
            float s = j / (float) n;
            float back = len * 0.78f * s;
            float rise = len * (0.62f * s * s - 0.12f * s) + lift * s;
            float sway = Mth.sin(phase + s * 3.2f) * 0.28f * s;
            float bob = Mth.cos(phase * 0.7f + s * 2.5f) * 0.12f * s;
            double x = Mth.sin(a) * back + Mth.cos(a) * sway;
            double z = Mth.cos(a) * back - Mth.sin(a) * sway * 0.3;
            pts.add(root.add(x, -(rise + bob), z));
        }
        return pts;
    }

    /** A tail of the skeleton form: a chain of vertebrae, each with a spine standing up off it. */
    private static void vertebrae(VertexConsumer vc, PoseStack ps, List<Vec3> pts, float[] radii, FxDraw.Paint bone, FxDraw.Paint shade) {
        int L = LightTexture.FULL_BRIGHT;
        FxDraw.tube(vc, ps, pts, scaled(radii, 0.38f), 6, shade, 1f, L, true);          // the cord through them
        for (int j = 0; j < pts.size() - 1; j++) {
            Vec3 p = pts.get(j), q = pts.get(j + 1);
            float r = Math.max(0.025f, radii[j] * 0.85f);
            FxDraw.sphere(vc, ps, p, r, 5, 7, bone, L);
            Vec3 dir = q.subtract(p);
            Vec3 up = new Vec3(0, -1, 0);
            Vec3 side = dir.cross(up);
            Vec3 spineDir = side.lengthSqr() < 1e-6 ? up : dir.cross(side).normalize();
            if (spineDir.y > 0) spineDir = spineDir.scale(-1);                         // spines point up and out
            FxDraw.cone(vc, ps, p, p.add(spineDir.scale(r * 2.4f)), r * 0.45f, 5, bone, L);
        }
    }

    private static float[] scaled(float[] a, float k) {
        float[] o = new float[a.length];
        for (int i = 0; i < a.length; i++) o[i] = a[i] * k;
        return o;
    }

    /** The skeleton round the body (body space): spine, ribcage, shoulder blades and pelvis. */
    private static void torsoBones(VertexConsumer vc, PoseStack ps, FxDraw.Paint bone, FxDraw.Paint shade, FxDraw.Paint glow, float t) {
        int L = LightTexture.FULL_BRIGHT;
        float breathe = 1f + 0.03f * Mth.sin(t * 0.15f);
        // the spine
        for (int k = 0; k <= 9; k++) {
            float y = 0.02f + k * 0.072f;
            FxDraw.box(vc, ps, new Vec3(0, y, 0.2), new Vec3(0.055, 0, 0), new Vec3(0, 0.026, 0), new Vec3(0, 0, 0.04), bone, L);
            FxDraw.cone(vc, ps, new Vec3(0, y, 0.22), new Vec3(0, y - 0.05, 0.36), 0.03f, 4, shade, L);
        }
        // the ribs: arcs from the spine round the sides, nearly meeting at the breastbone
        for (int k = 0; k < 6; k++) {
            float y = 0.1f + k * 0.065f;
            float w = (0.36f - Math.abs(k - 2) * 0.02f) * breathe, dz = 0.24f * breathe;
            for (int sx = -1; sx <= 1; sx += 2) {
                List<Vec3> rib = new ArrayList<>();
                for (int j = 0; j <= 8; j++) {
                    float a = j / 8f * Mth.PI * 0.92f;                 // from the back round to the front
                    rib.add(new Vec3(sx * Mth.sin(a) * w, y + j * 0.012f, Mth.cos(a) * dz));
                }
                FxDraw.tube(vc, ps, rib, new float[]{0.03f, 0.03f, 0.028f, 0.027f, 0.026f, 0.025f, 0.024f, 0.022f, 0.02f}, 5, bone, 1f, L, true);
            }
        }
        FxDraw.box(vc, ps, new Vec3(0, 0.28, -0.25), new Vec3(0.035, 0, 0), new Vec3(0, 0.18, 0), new Vec3(0, 0, 0.02), bone, L);   // breastbone
        // shoulder blades and collarbones
        for (int sx = -1; sx <= 1; sx += 2) {
            FxDraw.quad(vc, ps, new Vec3(sx * 0.08, 0.04, 0.25), new Vec3(sx * 0.3, 0.02, 0.24), new Vec3(sx * 0.22, 0.3, 0.26),
                    new Vec3(sx * 0.1, 0.22, 0.26), shade, L);
            FxDraw.tube(vc, ps, List.of(new Vec3(0, 0.02, -0.24), new Vec3(sx * 0.18, 0.0, -0.22), new Vec3(sx * 0.33, -0.02, -0.05)),
                    new float[]{0.025f, 0.03f, 0.035f}, 5, bone, 1f, L, true);
        }
        // the pelvis
        FxDraw.ring(vc, ps, new Vec3(0, 0.72, 0), new Vec3(0, 1, 0.25), 0.3f, 0.07f, 20, bone, shade, L);
        // a glow of the beast's chakra inside the ribs
        FxDraw.sphere(vc, ps, new Vec3(0, 0.32, 0), 0.22f * breathe, 6, 10, glow, L);
    }

    /** The skeleton's skull over the head (head space: y down, the face toward -z): brow, cheeks, sockets, jaw and fangs. */
    private static void skull(VertexConsumer vc, PoseStack ps, FxDraw.Paint bone, FxDraw.Paint shade, float t) {
        int L = LightTexture.FULL_BRIGHT;
        float jaw = 0.03f + 0.03f * Mth.sin(t * 0.2f);                // the jaw works slowly, like it's growling
        // the cranium: a plate over the top and back of the head
        FxDraw.box(vc, ps, new Vec3(0, -0.53, 0.02), new Vec3(0.29, 0, 0), new Vec3(0, 0.035, 0), new Vec3(0, 0, 0.29), bone, L);
        FxDraw.box(vc, ps, new Vec3(0, -0.3, 0.3), new Vec3(0.27, 0, 0), new Vec3(0, 0.22, 0), new Vec3(0, 0, 0.03), shade, L);
        // the brow ridge, heavy and jutting, with a crest
        FxDraw.box(vc, ps, new Vec3(0, -0.36, -0.33), new Vec3(0.3, 0, 0), new Vec3(0, 0.04, 0), new Vec3(0, 0, 0.05), bone, L);
        FxDraw.cone(vc, ps, new Vec3(0, -0.4, -0.3), new Vec3(0, -0.62, -0.42), 0.06f, 5, bone, L);
        for (int sx = -1; sx <= 1; sx += 2) {
            // cheekbones and the sides of the sockets
            FxDraw.box(vc, ps, new Vec3(sx * 0.27, -0.2, -0.32), new Vec3(0.04, 0, 0), new Vec3(0, 0.13, 0), new Vec3(0, 0, 0.04), bone, L);
            FxDraw.box(vc, ps, new Vec3(sx * 0.12, -0.13, -0.34), new Vec3(0.09, 0, 0), new Vec3(0, 0.025, 0), new Vec3(0, 0, 0.03), shade, L);
        }
        FxDraw.box(vc, ps, new Vec3(0, -0.2, -0.35), new Vec3(0.025, 0, 0), new Vec3(0, 0.12, 0), new Vec3(0, 0, 0.03), bone, L);   // between the eyes
        // the upper teeth, then the jaw hanging a little open with its own fangs
        for (int f = -3; f <= 3; f++) {
            float big = Math.abs(f) == 2 ? 1.8f : 1f;
            FxDraw.cone(vc, ps, new Vec3(f * 0.065, -0.1, -0.33), new Vec3(f * 0.065, -0.1 + 0.07 * big, -0.34), 0.022f * big, 4, bone, L);
        }
        FxDraw.box(vc, ps, new Vec3(0, 0.02 + jaw, -0.2), new Vec3(0.27, 0, 0), new Vec3(0, 0.03, 0), new Vec3(0, 0, 0.16), bone, L);
        for (int f = -3; f <= 3; f++) {
            float big = Math.abs(f) == 1 ? 1.6f : 1f;
            FxDraw.cone(vc, ps, new Vec3(f * 0.07, -0.01 + jaw, -0.34), new Vec3(f * 0.07, -0.01 + jaw - 0.07 * big, -0.35), 0.022f * big, 4, bone, L);
        }
    }

    /**
     * How open the shroud's eyes are (1 open, 0 shut): a blink at a random moment every three and a half seconds or
     * so, sometimes a quick double blink. Every player blinks on their own time.
     */
    private static float blink(int id, float t) {
        int cycle = 70;
        long k = (long) Math.floor(t / cycle);
        float in = t - k * cycle;
        int h = (int) (k * 73856093L) ^ (id * 19349663);
        h ^= h >>> 13;
        h *= 0x5bd1e995;
        h ^= h >>> 15;
        float start = 8f + ((h >>> 8) & 0xFFFF) / 65535f * 50f;
        float open = shut(in - start);
        if (((h >>> 3) & 3) == 0) open = Math.min(open, shut(in - start - 6f));
        return open;
    }

    /** One blink, {@code d} ticks after it starts: two ticks closing, a tick shut, two ticks opening. */
    private static float shut(float d) {
        if (d < 0 || d > 5) return 1f;
        if (d < 2) return 1f - d / 2f;
        if (d < 3) return 0f;
        return (d - 3f) / 2f;
    }

    /** What grows on the shroud's head (head space: blocks, y down, the face toward -z). */
    private static void head(VertexConsumer vc, PoseStack ps, TailedBeast.HeadShape head, FxDraw.Paint p, FxDraw.Paint edge, float t) {
        int L = LightTexture.FULL_BRIGHT;
        float sway = Mth.sin(t * 0.1f) * 0.02f;
        for (int sx = -1; sx <= 1; sx += 2) {
            switch (head) {
                case ROUND_EARS -> FxDraw.sphere(vc, ps, new Vec3(sx * 0.23, -0.6, 0.02), 0.11f, 6, 8, p, L);
                case CAT_EARS -> FxDraw.cone(vc, ps, new Vec3(sx * 0.17, -0.5, 0), new Vec3(sx * 0.27 + sway, -0.82, 0.03), 0.1f, 8, p, L);
                case FOX_EARS -> {
                    FxDraw.cone(vc, ps, new Vec3(sx * 0.16, -0.5, 0.02), new Vec3(sx * 0.32 + sway, -0.98, 0.08), 0.11f, 8, p, L);
                    FxDraw.cone(vc, ps, new Vec3(sx * 0.16, -0.5, 0.02), new Vec3(sx * 0.34 + sway, -1.04, 0.09), 0.15f, 8, edge, L);
                }
                case HORNS -> FxDraw.cone(vc, ps, new Vec3(sx * 0.17, -0.47, -0.05), new Vec3(sx * 0.36, -0.82, 0.18), 0.07f, 8, p, L);
                case OX_HORNS -> {
                    List<Vec3> pts = List.of(new Vec3(sx * 0.2, -0.42, 0), new Vec3(sx * 0.42, -0.5, 0.02),
                            new Vec3(sx * 0.56, -0.68, 0.0), new Vec3(sx * 0.55, -0.9, -0.06));
                    FxDraw.tube(vc, ps, pts, new float[]{0.08f, 0.065f, 0.045f, 0.012f}, 8, p, 1f, L, true);
                }
                case ANTENNAE -> {
                    List<Vec3> pts = List.of(new Vec3(sx * 0.08, -0.5, -0.1), new Vec3(sx * 0.14 + sway, -0.75, -0.18),
                            new Vec3(sx * 0.26 + sway, -0.98, -0.3));
                    FxDraw.tube(vc, ps, pts, new float[]{0.03f, 0.022f, 0.012f}, 6, p, 1f, L, true);
                }
                case SPIKES -> FxDraw.cone(vc, ps, new Vec3(sx * 0.13, -0.5, 0.05), new Vec3(sx * 0.2, -0.72, 0.16), 0.07f, 6, p, L);
                case NONE -> {
                }
            }
        }
        if (head == TailedBeast.HeadShape.SPIKES) FxDraw.cone(vc, ps, new Vec3(0, -0.5, 0.0), new Vec3(0, -0.82, 0.12), 0.08f, 6, p, L);
    }

    private static float[] rgb(int c) {
        return new float[]{((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f};
    }

    private static float lift(float v) {
        return Math.min(1f, v + (1f - v) * 0.25f);
    }

    private static int brighten(int c) {
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        return (Math.min(255, r + (255 - r) / 2) << 16) | (Math.min(255, g + (255 - g) / 2) << 8) | Math.min(255, b + (255 - b) / 2);
    }
}
