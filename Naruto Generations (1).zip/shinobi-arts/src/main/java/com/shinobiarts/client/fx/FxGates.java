package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.EightGates;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * The Eight Gates' chakra (entityA = the user, size = gates open): it burns round them like fire, tongues of their gate's
 * colour licking up off the whole body, taller and wider with every gate, until at the eighth they're wreathed in a
 * blazing column. Re-sent every half second while the gates are open, so it goes when they close.
 */
final class FxGates {
    private FxGates() {}

    private static final ResourceLocation TONGUES = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/flame_tongues.png");

    /**
     * Charging chakra (size = the player's chakra colour as RGB): a blazing aura of that colour roaring up round
     * them, a ring of light on the ground at their feet, wisps streaking up past them.
     */
    static void chargeAura(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null || e.isInvisible()) return;
        int rgb = Math.round(c.fx().size) & 0xFFFFFF;
        // lightened, so the aura reads as pale glow and the player stays visible through it
        int r0 = 255 - (255 - ((rgb >> 16) & 255)) / 2, g0 = 255 - (255 - ((rgb >> 8) & 255)) / 2, b0 = 255 - (255 - (rgb & 255)) / 2;
        Minecraft mc = Minecraft.getInstance();
        boolean self = e == mc.player && mc.options.getCameraType().isFirstPerson();
        Vec3 base = e.getPosition(c.partial());
        float h = e.getBbHeight();
        float t = e.tickCount + c.partial();
        VertexConsumer vc = c.buffers().getBuffer(RenderType.entityTranslucentEmissive(TONGUES));
        RandomSource r = RandomSource.create(e.getId() * 31L + 7);
        int flames = self ? 10 : 34;
        for (int k = 0; k < flames; k++) {
            float ang = r.nextFloat() * Mth.TWO_PI;
            float phase = r.nextFloat();
            float col = r.nextInt(4);
            float life = (t / 9f + phase) % 1f;
            float size = 1.1f + 0.9f * Mth.sin(life * Mth.PI);
            double rad = self ? 0.9 : 0.45 + 0.25 * life;
            Vec3 at = base.add(Math.cos(ang) * rad, -0.2 + life * (h + 1.4f), Math.sin(ang) * rad);
            float alpha = Mth.sin(life * Mth.PI) * (self ? 0.15f : 0.32f);
            float u0 = col / 4f;
            FxDraw.Paint paint = new FxDraw.Paint(u0, 0f, u0 + 0.25f, 1f, r0, g0, b0, Math.round(255 * alpha));
            FxDraw.billboard(vc, c.ps(), c.camera(), at, size * 0.55f, size * 1.6f, 0f, paint, FxDraw.FULL);
        }
        VertexConsumer add = FxDraw.additive(c.buffers());
        float pulse = 0.5f + 0.5f * Mth.sin(t * 0.5f);
        FxDraw.ring(add, c.ps(), base.add(0, 0.05, 0), new Vec3(0, 1, 0), 0.9f + 0.2f * pulse, 0.5f, 32,
                FxDraw.addColor(rgb, 0.4f), FxDraw.addColor(rgb, 0f), FxDraw.FULL);
        if (!self) {
            for (int k = 0; k < 6; k++) {                              // streaks shooting up past them
                float life = (t / 6f + k / 6f) % 1f;
                float ang = k * 1.7f + (int) (t / 6f + k / 6f) * 2.3f;
                Vec3 a = base.add(Mth.cos(ang) * 0.7, life * (h + 2.5f), Mth.sin(ang) * 0.7);
                java.util.List<Vec3> streak = java.util.List.of(a.subtract(0, 0.9, 0), a);
                FxDraw.ribbon(add, c.ps(), c.cam(), streak, 0.08f, 0.2f, FxDraw.addColor(rgb, 0f),
                        FxDraw.addColor(0xFFFFFF, 0.6f * Mth.sin(life * Mth.PI)), FxDraw.FULL);
            }
        }
    }

    private static final ResourceLocation FOG = new ResourceLocation(ShinobiArts.MODID, "textures/entity/susanoo/fog.png");

    /**
     * The open gates' chakra, the same glowing fog that drifts off a Susanoo (entityA = the user, size = gates open): soft
     * puffs of the gate's colour born all over the body, swelling as they rise and drift outward, then fading, in an
     * endless stream. More puffs, bigger and faster with every gate; still see-through, so the player shows inside it.
     */
    static void flame(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null || e.isInvisible()) return;
        int gates = Mth.clamp(Math.round(c.fx().size), 1, 8);
        Minecraft mc = Minecraft.getInstance();
        boolean self = e == mc.player && mc.options.getCameraType().isFirstPerson();
        int rgb = EightGates.AURA_RGB[gates];
        float[] col = {((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f};
        float[] light = {col[0] * 0.6f + 0.4f, col[1] * 0.6f + 0.4f, col[2] * 0.6f + 0.4f};
        Vec3 base = e.getPosition(c.partial());
        float h = e.getBbHeight(), w = e.getBbWidth();
        float t = e.tickCount + c.partial();
        VertexConsumer vc = c.buffers().getBuffer(RenderType.entityTranslucentEmissive(FOG));
        RandomSource r = RandomSource.create(e.getId() * 7919L);
        int puffs = self ? 4 + gates : 8 + gates * 4;                       // capped: at most 40 quads
        float rise = 0.9f + gates * 0.22f, swell = 0.35f + gates * 0.08f;
        float cycle = 40f - gates * 2.5f;
        for (int k = 0; k < puffs; k++) {
            float ang = r.nextFloat() * Mth.TWO_PI;
            float y0 = r.nextFloat() * h * 0.95f;
            float offset = r.nextFloat();
            float life = (t / cycle + offset) % 1f;                          // 0 born .. 1 gone
            double rad = w * 0.55 + life * (0.25 + gates * 0.05);
            if (self) rad += 0.5;                                            // in first person: around you, not in your face
            Vec3 at = base.add(Math.cos(ang) * rad, y0 + life * rise, Math.sin(ang) * rad);
            float size = swell * (0.5f + 1.2f * life);
            float alpha = Mth.sin(life * Mth.PI) * (self ? 0.12f : 0.2f + gates * 0.018f);
            float[] cc = life < 0.3f ? light : col;
            FxDraw.Paint paint = new FxDraw.Paint(0f, 0f, 1f, 1f, Math.round(cc[0] * 255), Math.round(cc[1] * 255), Math.round(cc[2] * 255),
                    Math.round(255 * alpha));
            FxDraw.billboard(vc, c.ps(), c.camera(), at, size, size, offset * 6.28f + t * 0.01f, paint, FxDraw.FULL);
        }
    }

}
