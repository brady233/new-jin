package com.shinobiarts.network;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: the bounty board (every wanted ninja's info card), for the Bounties page of the ninja menu. */
public class BountyBoardPacket {
    private final CompoundTag tag;

    public BountyBoardPacket(CompoundTag tag) {
        this.tag = tag;
    }

    public BountyBoardPacket(FriendlyByteBuf buf) {
        CompoundTag read = buf.readNbt();
        this.tag = read == null ? new CompoundTag() : read;
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeNbt(tag);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.shinobiarts.client.ClientHooks.bountyBoard(tag));
    }
}
