package com.shinobiarts.item;

import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * XP boost token: right-click to multiply the ninja XP you earn (mob kills, PvP) for a while.
 * The timer only runs while you're online. Using the same multiplier again adds time; a stronger token
 * replaces a weaker boost; a weaker token can't be used while a stronger boost is running.
 */
public class XpBoostItem extends Item {
    private final float multiplier;
    private final int minutes;

    public XpBoostItem(float multiplier, int minutes, Properties properties) {
        super(properties);
        this.multiplier = multiplier;
        this.minutes = minutes;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(player instanceof ServerPlayer sp)) return InteractionResultHolder.success(stack);
        NinjaData d = NinjaData.get(sp);
        if (d == null) return InteractionResultHolder.pass(stack);
        int ticks = minutes * 60 * 20;
        String mult = format(multiplier);
        if (d.getBoostTicks() > 0 && d.getBoostMultiplier() > multiplier) {
            sp.displayClientMessage(Component.translatable("message.shinobiarts.boost_stronger", format(d.getBoostMultiplier()))
                    .withStyle(ChatFormatting.RED), true);
            return InteractionResultHolder.fail(stack);
        }
        if (d.getBoostTicks() > 0 && d.getBoostMultiplier() == multiplier) {
            d.setBoost(multiplier, d.getBoostTicks() + ticks);
            sp.sendSystemMessage(Component.translatable("message.shinobiarts.boost_extended", mult, d.getBoostTicks() / 1200)
                    .withStyle(ChatFormatting.GREEN));
        } else {
            d.setBoost(multiplier, ticks);
            sp.sendSystemMessage(Component.translatable("message.shinobiarts.boost_started", mult, minutes).withStyle(ChatFormatting.GREEN));
        }
        if (!sp.getAbilities().instabuild) stack.shrink(1);
        level.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.7f, 1.6f);
        ModNetwork.sync(sp);
        return InteractionResultHolder.consume(stack);
    }

    public static String format(float multiplier) {
        return multiplier == Math.floor(multiplier) ? String.valueOf((int) multiplier) : String.valueOf(multiplier);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shinobiarts.xp_boost", format(multiplier), minutes).withStyle(ChatFormatting.GRAY));
    }
}
