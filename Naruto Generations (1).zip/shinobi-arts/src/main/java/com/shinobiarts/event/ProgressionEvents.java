package com.shinobiarts.event;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.ShadowClone;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.pvp.PvpRewards;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Ninja XP from mobs: 5 XP per hostile mob kill by default (your clones' and jutsu kills count). XP boosts apply. */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ProgressionEvents {
    private ProgressionEvents() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onMobDeath(LivingDeathEvent event) {
        // Izanagi: a death inside its window never happened
        if (event.getEntity() instanceof net.minecraft.server.level.ServerPlayer sp && com.shinobiarts.jutsu.ForbiddenEyeJutsu.izanagiSaves(sp)) {
            event.setCanceled(true);
            return;
        }
        LivingEntity victim = event.getEntity();
        if (event.isCanceled() || victim.level().isClientSide || victim instanceof Player || victim instanceof ShadowClone) return;
        if (!Config.b(Config.MOB_XP_ALL_MOBS) && !(victim instanceof Enemy)) return;
        ServerPlayer killer = PvpRewards.responsiblePlayer(event.getSource());
        int base = Config.i(Config.MOB_KILL_XP);
        if (killer == null || base <= 0) return;
        NinjaData d = NinjaData.get(killer);
        long gained = Math.round(base * (double) (d == null ? 1f : d.getBoostMultiplier()));
        PlayerDataManager.addEarnedXp(killer, base);
        killer.displayClientMessage(Component.translatable("message.shinobiarts.xp_gained", gained).withStyle(ChatFormatting.GREEN), true);
    }
}
