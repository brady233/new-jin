package com.shinobiarts.village;

import net.minecraft.core.NonNullList;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * The village storage as a container that works directly on the saved slots (like a real chest), so
 * several viewers and quest hand-ins always see the same items: nothing is copied, so nothing can be duplicated.
 */
public class VillageStorageContainer implements Container {
    private final NonNullList<ItemStack> slots;
    private final VillageData data;

    public VillageStorageContainer(NonNullList<ItemStack> slots, VillageData data) {
        this.slots = slots;
        this.data = data;
    }

    @Override
    public int getContainerSize() {
        return slots.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack s : slots) {
            if (!s.isEmpty()) return false;
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return slots.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack out = ContainerHelper.removeItem(slots, slot, amount);
        if (!out.isEmpty()) setChanged();
        return out;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        ItemStack out = ContainerHelper.takeItem(slots, slot);
        setChanged();
        return out;
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        slots.set(slot, stack);
        setChanged();
    }

    @Override
    public void setChanged() {
        data.setDirty();
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    @Override
    public void clearContent() {
        slots.clear();
        setChanged();
    }
}
