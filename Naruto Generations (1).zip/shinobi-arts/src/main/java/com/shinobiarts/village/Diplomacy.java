package com.shinobiarts.village;

import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Relations between villages: alliances and wars (saved with the world, server-side only).
 * <p>
 * A Kage can only <i>propose</i> (an alliance, a war, peace, or breaking an alliance) from the Diplomacy tab of the Kage
 * menu. Every proposal waits for an operator: {@code /diplomacy pending}, {@code /diplomacy accept <id>},
 * {@code /diplomacy deny <id>}. Only then does it take effect, and both villages are told.
 * <p>
 * What they mean in play: members of allied villages can't hurt each other; killing a member of a village yours is at
 * war with pays extra PvP rewards (see PvpRewards).
 */
public final class Diplomacy extends SavedData {
    public enum Relation { NEUTRAL, ALLIED, WAR }

    public enum Proposal {
        ALLIANCE, WAR, PEACE, BREAK_ALLIANCE;

        public static Proposal byOrdinal(int i) {
            Proposal[] all = values();
            return i >= 0 && i < all.length ? all[i] : null;
        }

        public Component displayName() {
            return Component.translatable("diplomacy.shinobiarts.kind." + name().toLowerCase(java.util.Locale.ROOT));
        }
    }

    public static final class Request {
        public final int id;
        public final String from, to, by;
        public final Proposal kind;
        public final long time;

        Request(int id, String from, String to, Proposal kind, String by, long time) {
            this.id = id;
            this.from = from;
            this.to = to;
            this.kind = kind;
            this.by = by;
            this.time = time;
        }
    }

    private final Map<String, Relation> relations = new LinkedHashMap<>();
    private final List<Request> pending = new ArrayList<>();
    private int nextId = 1;

    public static Diplomacy get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(Diplomacy::load, Diplomacy::new, "shinobiarts_diplomacy");
    }

    private static String key(String a, String b) {
        return a.compareTo(b) <= 0 ? a + "|" + b : b + "|" + a;
    }

    public Relation relation(String a, String b) {
        if (a == null || b == null || a.isEmpty() || b.isEmpty() || a.equals(b)) return Relation.NEUTRAL;
        return relations.getOrDefault(key(a, b), Relation.NEUTRAL);
    }

    public boolean allied(String a, String b) {
        return relation(a, b) == Relation.ALLIED;
    }

    public boolean atWar(String a, String b) {
        return relation(a, b) == Relation.WAR;
    }

    public List<Request> pending() {
        return pending;
    }

    @Nullable
    public Request pendingBetween(String a, String b) {
        for (Request r : pending) {
            if ((r.from.equals(a) && r.to.equals(b)) || (r.from.equals(b) && r.to.equals(a))) return r;
        }
        return null;
    }

    /** A Kage proposes something. Checked here (server side): the Kage's own village, a sensible change, nothing pending. */
    public static void propose(ServerPlayer kage, String target, Proposal kind) {
        NinjaData d = NinjaData.get(kage);
        if (d == null || !d.isKage() || kind == null) return;
        String from = d.getVillage();
        if (from.isEmpty() || target.equals(from) || Villages.byId(target) == null) return;
        Diplomacy dip = get(kage.server);
        Relation now = dip.relation(from, target);
        boolean sensible = switch (kind) {
            case ALLIANCE -> now == Relation.NEUTRAL;
            case WAR -> now != Relation.WAR;
            case PEACE -> now == Relation.WAR;
            case BREAK_ALLIANCE -> now == Relation.ALLIED;
        };
        if (!sensible) {
            kage.displayClientMessage(Component.translatable("message.shinobiarts.diplomacy_invalid").withStyle(ChatFormatting.RED), true);
            return;
        }
        if (dip.pendingBetween(from, target) != null) {
            kage.displayClientMessage(Component.translatable("message.shinobiarts.diplomacy_already_pending").withStyle(ChatFormatting.RED), true);
            return;
        }
        Request r = new Request(dip.nextId++, from, target, kind, kage.getGameProfile().getName(), System.currentTimeMillis());
        dip.pending.add(r);
        dip.setDirty();
        kage.sendSystemMessage(Component.translatable("message.shinobiarts.diplomacy_sent", kind.displayName(), Villages.name(target))
                .withStyle(ChatFormatting.GOLD));
        Component note = Component.translatable("message.shinobiarts.diplomacy_op_notice", r.id, Villages.name(from), kind.displayName(),
                Villages.name(target), r.by).withStyle(ChatFormatting.YELLOW);
        for (ServerPlayer p : kage.server.getPlayerList().getPlayers()) {
            if (p.hasPermissions(2)) p.sendSystemMessage(note);
        }
    }

    /** An operator decides a request. Returns false if there's no such request. */
    public static boolean decide(MinecraftServer server, int id, boolean accept) {
        Diplomacy dip = get(server);
        Request r = null;
        for (Request q : dip.pending) {
            if (q.id == id) {
                r = q;
                break;
            }
        }
        if (r == null) return false;
        dip.pending.remove(r);
        if (accept) {
            Relation to = switch (r.kind) {
                case ALLIANCE -> Relation.ALLIED;
                case WAR -> Relation.WAR;
                case PEACE, BREAK_ALLIANCE -> Relation.NEUTRAL;
            };
            if (to == Relation.NEUTRAL) dip.relations.remove(key(r.from, r.to));
            else dip.relations.put(key(r.from, r.to), to);
        }
        dip.setDirty();
        Component msg = Component.translatable(accept ? "message.shinobiarts.diplomacy_accepted" : "message.shinobiarts.diplomacy_denied",
                r.kind.displayName(), Villages.name(r.from), Villages.name(r.to)).withStyle(accept ? ChatFormatting.GREEN : ChatFormatting.RED);
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            NinjaData pd = NinjaData.get(p);
            if (pd != null && (r.from.equals(pd.getVillage()) || r.to.equals(pd.getVillage()))) p.sendSystemMessage(msg);
        }
        return true;
    }

    /** For the Kage menu's Diplomacy tab: every other village, how it stands with yours, and anything pending. */
    public static ListTag table(MinecraftServer server, String village) {
        Diplomacy dip = get(server);
        ListTag list = new ListTag();
        for (Villages.Village v : Villages.all()) {
            if (v.id().equals(village)) continue;
            CompoundTag t = new CompoundTag();
            t.putString("Id", v.id());
            t.putString("Name", v.name());
            t.putInt("Relation", dip.relation(village, v.id()).ordinal());
            Request r = dip.pendingBetween(village, v.id());
            t.putInt("Pending", r == null ? -1 : r.kind.ordinal());
            list.add(t);
        }
        return list;
    }

    // ---------------------------------------------------------------- saving

    static Diplomacy load(CompoundTag tag) {
        Diplomacy d = new Diplomacy();
        CompoundTag rel = tag.getCompound("Relations");
        for (String k : rel.getAllKeys()) {
            int o = rel.getInt(k);
            if (o > 0 && o < Relation.values().length) d.relations.put(k, Relation.values()[o]);
        }
        for (Tag t : tag.getList("Pending", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) t;
            Proposal k = Proposal.byOrdinal(c.getInt("Proposal"));
            if (k != null) d.pending.add(new Request(c.getInt("Id"), c.getString("From"), c.getString("To"), k, c.getString("By"), c.getLong("Time")));
        }
        d.nextId = Math.max(1, tag.getInt("NextId"));
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        CompoundTag rel = new CompoundTag();
        relations.forEach((k, v) -> rel.putInt(k, v.ordinal()));
        tag.put("Relations", rel);
        ListTag list = new ListTag();
        for (Request r : pending) {
            CompoundTag c = new CompoundTag();
            c.putInt("Id", r.id);
            c.putString("From", r.from);
            c.putString("To", r.to);
            c.putInt("Proposal", r.kind.ordinal());
            c.putString("By", r.by);
            c.putLong("Time", r.time);
            list.add(c);
        }
        tag.put("Pending", list);
        tag.putInt("NextId", nextId);
        return tag;
    }
}
