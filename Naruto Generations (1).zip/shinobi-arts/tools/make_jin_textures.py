"""
The jinchuriki shroud's textures (textures/entity/jinchuriki/, white: the code tints them the beast's colour):

  shroud.png   the rage forms: boiling chakra, soft rising streaks and bubbles, brighter toward the top
  cloak.png    the tamed chakra cloak: calmer upward flow with thin, clean line markings

Run: python3 tools/make_jin_textures.py   (needs numpy and Pillow)
"""
import os

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts", "textures", "entity", "jinchuriki")
W, H = 64, 32


def noise(rng, w, h, octaves=4, stretch=1.0):
    out = np.zeros((h, w))
    for o in range(octaves):
        sx = max(2, int(3 * 2 ** o / stretch))
        sy = 3 * 2 ** o
        g = rng.random((sy + 1, sx + 1))
        g[:, -1] = g[:, 0]                                    # tiles sideways (the swirl scrolls)
        img = Image.fromarray((g * 255).astype(np.uint8)).resize((w, h), Image.BICUBIC)
        out += np.asarray(img).astype(float) / 255 / (o + 1)
    return out / sum(1 / (o + 1) for o in range(octaves))


def shroud():
    rng = np.random.default_rng(9)
    y = np.linspace(0, 1, H)[:, None]
    x = np.linspace(0, 1, W)[None, :]
    # upward flow: the noise sheared into soft vertical streaks, denser and brighter higher up
    flow = noise(rng, W, H, 4, stretch=2.5)
    streaks = 0.5 + 0.5 * np.sin(x * np.pi * 10 + flow * 6)
    body = 0.45 + 0.4 * flow + 0.25 * streaks * (1 - y * 0.6)
    # bubbles boiling through it
    yy, xx = np.mgrid[0:H, 0:W]
    for _ in range(26):
        cx, cy, r = rng.uniform(0, W), rng.uniform(0, H), rng.uniform(1.2, 3.2)
        dx = np.minimum(np.abs(xx - cx), W - np.abs(xx - cx))
        d = np.hypot(dx, yy - cy)
        body += 0.35 * np.exp(-(d / r) ** 2)
    body = np.clip(body * (1.05 - 0.25 * y), 0, 1)
    img = np.zeros((H, W, 4))
    img[..., :3] = 255
    img[..., 3] = 90 + body * 165
    Image.fromarray(img.astype(np.uint8), "RGBA").save(os.path.join(OUT, "shroud.png"))


def cloak():
    rng = np.random.default_rng(21)
    y = np.linspace(0, 1, H)[:, None]
    flow = noise(rng, W, H, 4, stretch=3.0)
    x = np.linspace(0, 1, W)[None, :]
    body = 0.55 + 0.3 * flow + 0.15 * np.sin(x * np.pi * 8 + flow * 4) * (1 - y * 0.5)
    img = np.zeros((H, W, 4))
    img[..., :3] = 255
    img[..., 3] = np.clip(120 + body * 120, 0, 255)
    im = Image.fromarray(img.astype(np.uint8), "RGBA")
    # thin, clean markings: straight seal lines with small hooks, like stitched chakra seams
    marks = Image.new("L", (W * 4, H * 4), 0)
    d = ImageDraw.Draw(marks)
    rnd = np.random.default_rng(5)
    for k in range(6):
        x0 = int(rnd.uniform(0, W * 4))
        y0 = int(rnd.uniform(2, H * 2))
        L = int(rnd.uniform(20, 44))
        d.line((x0, y0, x0, y0 + L), fill=255, width=3)
        hook = 10 if rnd.random() < 0.5 else -10
        d.line((x0, y0 + L, x0 + hook, y0 + L), fill=255, width=3)
        d.line((x0, y0, x0 - hook, y0), fill=255, width=3)
    marks = marks.filter(ImageFilter.GaussianBlur(0.8)).resize((W, H), Image.LANCZOS)
    px = np.asarray(im).astype(float)
    m = np.asarray(marks).astype(float) / 255
    px[..., :3] = px[..., :3] * (1 - m[..., None] * 0.75)       # the marks darken (the tint shows them as deep colour)
    px[..., 3] = np.maximum(px[..., 3], m * 255)
    Image.fromarray(np.clip(px, 0, 255).astype(np.uint8), "RGBA").save(os.path.join(OUT, "cloak.png"))


if __name__ == "__main__":
    shroud()
    cloak()
    print("jinchuriki textures written")
