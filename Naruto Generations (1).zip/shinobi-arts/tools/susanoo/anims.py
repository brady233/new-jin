"""
Keyframed Susanoo actions, one set per stage: the three combo swings, the special (right-click) and the blocking pose.
Each action is a list of (tick, {bone: [x, y, z] degrees}); a bone missing from a key is at rest there. Rotations are
applied Z, then Y, then X (like Minecraft's model parts) about the bone's pivot. In model space the Susanoo faces +Z,
its right side is -X, so for a limb hanging down a negative X angle swings it forward and up, a positive Y angle turns
it toward the model's left. Idle breathing, walking and wing flaps are worked out in the mod (SusanooPose.java).

The server's hit ticks (when damage lands) are in Susanoo.java and match the strike keys here:
swings at tick 7 (the third at 9), specials at tick 12 (stage 3: 9, stage 5: 14).
"""

# claws / fists without a weapon (stage 2)
S2 = {
    "swing1": {"len": 14, "keys": [(0, {}),
                                   (4, {"arm_r": [-60, -55, 0], "fore_r": [-15, 0, 0], "body": [0, -12, 0]}),
                                   (7, {"arm_r": [-78, 45, 0], "fore_r": [-5, 0, 0], "body": [0, 12, 0]}),
                                   (14, {})]},
    "swing2": {"len": 14, "keys": [(0, {}),
                                   (4, {"arm_l": [-60, 55, 0], "fore_l": [-15, 0, 0], "body": [0, 12, 0]}),
                                   (7, {"arm_l": [-78, -45, 0], "fore_l": [-5, 0, 0], "body": [0, -12, 0]}),
                                   (14, {})]},
    "swing3": {"len": 16, "keys": [(0, {}),
                                   (5, {"arm_r": [-155, 10, 0], "arm_l": [-155, -10, 0], "body": [-8, 0, 0], "jaw": [18, 0, 0]}),
                                   (9, {"arm_r": [-55, 10, 0], "arm_l": [-55, -10, 0], "body": [18, 0, 0], "jaw": [5, 0, 0]}),
                                   (16, {})]},
    "special": {"len": 22, "keys": [(0, {}),
                                    (8, {"arm_r": [-165, 15, 0], "arm_l": [-165, -15, 0], "body": [-12, 0, 0], "head": [-10, 0, 0], "jaw": [25, 0, 0]}),
                                    (12, {"arm_r": [-40, 10, 0], "arm_l": [-40, -10, 0], "body": [25, 0, 0], "jaw": [10, 0, 0]}),
                                    (22, {})]},
    "block": {"arm_r": [-65, 40, 0], "fore_r": [-35, 0, 0], "arm_l": [-65, -40, 0], "fore_l": [-35, 0, 0], "body": [6, 0, 0]},
}

# ---------------------------------------------------------------- each Mangekyou's own moves (stages 3-5)
# Every hand holds its design's weapon rigidly, so turning the wrist (hand_r / hand_l) turns the blade with it.

def mirror(pose):
    """The same pose on the other side: right bones to left (Y and Z turned the other way), and back."""
    out = {}
    for bone, (x, y, z) in pose.items():
        if bone.endswith("_r"):
            bone = bone[:-2] + "_l"
        elif bone.endswith("_l"):
            bone = bone[:-2] + "_r"
        elif bone in ("torso", "body", "head"):
            pass
        out[bone] = [x, -y, -z]
    return out


def act(length, *keys):
    return {"len": length, "keys": [(0, {})] + list(keys) + [(length, {})]}


# a one-handed cut with the right hand: wind up across, cut through (strike at tick 7)
CUT_R = act(14, (4, {"arm_r": [-20, -70, 0], "fore_r": [-15, 0, 0], "hand_r": [0, 0, -30], "torso": [0, -25, 0]}),
            (7, {"arm_r": [-25, 55, 0], "fore_r": [-5, 0, 0], "hand_r": [10, 0, 35], "torso": [0, 25, 0]}))
BACK_R = act(14, (4, {"arm_r": [-25, 55, 0], "fore_r": [-5, 0, 0], "hand_r": [10, 0, 35], "torso": [0, 25, 0]}),
             (7, {"arm_r": [-20, -70, 0], "fore_r": [-15, 0, 0], "hand_r": [0, 0, -30], "torso": [0, -25, 0]}))
# raised high and brought straight down (strike at 9)
OVERHEAD_R = act(16, (5, {"arm_r": [-150, 10, 0], "fore_r": [-25, 0, 0], "hand_r": [-35, 0, 0], "torso": [-10, 0, 0]}),
                 (9, {"arm_r": [-15, 10, 0], "fore_r": [0, 0, 0], "hand_r": [40, 0, 0], "torso": [15, 0, 0]}))
CUT_L = {"len": 14, "keys": [(t, mirror(p)) for t, p in CUT_R["keys"]]}
BOTH_OVERHEAD = act(16, (5, {**OVERHEAD_R["keys"][1][1], **mirror({"arm_r": [-150, 10, 0], "fore_r": [-25, 0, 0], "hand_r": [-35, 0, 0]})}),
                    (9, {**OVERHEAD_R["keys"][2][1], **mirror({"arm_r": [-15, 10, 0], "fore_r": [0, 0, 0], "hand_r": [40, 0, 0]})}))


def special_overhead(strike, both=False, wings=False):
    up = {"arm_r": [-150, 15, 0], "fore_r": [-30, 0, 0], "hand_r": [-40, 0, 0], "torso": [-12, -10, 0]}
    down = {"arm_r": [5, 20, 0], "fore_r": [0, 0, 0], "hand_r": [45, 0, 0], "torso": [18, 10, 0]}
    if both:
        up.update(mirror({k: v for k, v in up.items() if k.endswith("_r")}))
        down.update(mirror({k: v for k, v in down.items() if k.endswith("_r")}))
        up["torso"], down["torso"] = [-12, 0, 0], [18, 0, 0]
    if wings:
        up.update({"wing_r": [0, 0, -20], "wing_l": [0, 0, 20]})
        down.update({"wing_r": [0, 0, 15], "wing_l": [0, 0, -15]})
    return act(strike + 10, (strike - 4, up), (strike, down))


def special_bow(strike, wings=False):
    """Sasuke: the bow thrust out in front, the string drawn back to the cheek, loosed at the strike."""
    draw = {"arm_l": [-80, -25, 0], "fore_l": [0, 0, 0], "hand_l": [80, 0, -10],          # the bow upright, out in front
            "arm_r": [-80, 40, 0], "fore_r": [-100, 0, 0], "hand_r": [0, 0, 0], "torso": [0, 20, 0], "head": [0, 12, 0]}
    loose = {"arm_l": [-80, -25, 0], "hand_l": [80, 0, -10], "arm_r": [-70, 65, 0], "fore_r": [-20, 0, 0], "hand_r": [20, 0, 30],
             "torso": [0, 20, 0], "head": [0, 12, 0]}
    if wings:
        draw.update({"wing_r": [0, 25, -10], "wing_l": [0, -25, 10]})
    return {"len": strike + 12, "keys": [(0, {}), (strike - 6, draw), (strike - 1, draw), (strike, loose), (strike + 12, {})]}


def special_throw(strike, wings=False):
    """Obito: both shuriken brought back over the shoulders, then whipped forward and let go."""
    back = {"arm_r": [-160, 35, 0], "fore_r": [-40, 0, 0], "hand_r": [-30, 0, 0], "torso": [-10, 0, 0]}
    back.update(mirror({k: v for k, v in back.items() if k.endswith("_r")}))
    fwd = {"arm_r": [-70, -20, 0], "fore_r": [0, 0, 0], "hand_r": [50, 0, 0], "torso": [12, 0, 0]}
    fwd.update(mirror({k: v for k, v in fwd.items() if k.endswith("_r")}))
    if wings:
        back.update({"wing_r": [0, 0, -15], "wing_l": [0, 0, 15]})
    return act(strike + 10, (strike - 4, back), (strike, fwd))


THROW_L = {"len": 18, "keys": [(0, {}),                       # the magatama, thrown with the left hand (stage 3)
                               (6, {"arm_l": [-30, -40, 0], "hand_l": [-20, 0, 0], "torso": [0, 20, 0]}),
                               (9, {"arm_l": [-95, 10, 0], "fore_l": [-10, 0, 0], "hand_l": [30, 0, 0], "torso": [0, -15, 0]}),
                               (18, {})]}

SPECIAL_TICK = {3: 9, 4: 12, 5: 14}


def design_anims(design, stage):
    strike = SPECIAL_TICK[stage]
    wings = stage == 5
    if design == "itachi":           # the Totsuka in the right hand, the Yata Mirror raised to block
        a = {"swing1": CUT_R, "swing2": BACK_R, "swing3": OVERHEAD_R,
             "special": THROW_L if stage == 3 else special_overhead(strike, wings=wings),
             "block": {"arm_l": [-25, -45, 0], "fore_l": [-40, 0, 0], "hand_l": [30, 0, 0], "arm_r": [-10, 20, 0]}}   # mirror before the face
    elif design == "sasuke":         # the sword, and the bow for the special (an arrow)
        a = {"swing1": CUT_R, "swing2": BACK_R, "swing3": OVERHEAD_R, "special": special_bow(strike, wings),
             "block": {"arm_r": [-45, 60, 0], "fore_r": [-20, 0, 0], "hand_r": [0, 0, 20], "arm_l": [-30, -20, 0]}}
    elif design == "obito":          # a Kamui shuriken in each hand
        a = {"swing1": CUT_R, "swing2": CUT_L, "swing3": BOTH_OVERHEAD, "special": special_throw(strike, wings),
             "block": {"arm_r": [-60, 40, 0], "fore_r": [-30, 0, 0], "arm_l": [-60, -40, 0], "fore_l": [-30, 0, 0]}}
    else:                            # madara: twin swords
        a = {"swing1": CUT_R, "swing2": CUT_L, "swing3": BOTH_OVERHEAD, "special": special_overhead(strike, both=True, wings=wings),
             "block": {"arm_r": [-60, 45, 0], "fore_r": [-35, 0, 0], "hand_r": [0, 0, 25],
                       "arm_l": [-60, -45, 0], "fore_l": [-35, 0, 0], "hand_l": [0, 0, -25]}}
    a = dict(a)
    if wings:
        a["block"] = {**a["block"], "wing_r": [0, 70, -10], "wing_l": [0, -70, 10]}
    return a


DESIGNS = ("itachi", "sasuke", "obito", "madara")
S3 = design_anims("itachi", 3)
S4 = design_anims("itachi", 4)
S5 = design_anims("itachi", 5)

S1 = {"block": {"body": [8, 0, 0]}}

ANIMS = {1: S1, 2: S2, 3: S3, 4: S4, 5: S5}
for _d in DESIGNS:
    for _n in (3, 4, 5):
        ANIMS[f"{_n}_{_d}"] = design_anims(_d, _n)

# bones moved to another parent for animation (none any more: every weapon is built onto its hand)
REPARENT = {}


def to_json():
    out = {}
    for stage, acts in ANIMS.items():
        o = {}
        for name, a in acts.items():
            if name == "block":
                o[name] = {b: [float(v) for v in r] for b, r in a.items()}
            else:
                o[name] = {"len": a["len"], "keys": [[t, {b: [float(v) for v in r] for b, r in pose.items()}] for t, pose in a["keys"]]}
        out[str(stage)] = o
    return out
