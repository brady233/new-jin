"""
The Hoshigaki shark form's skins (player skin layout, laid over the player by client/SharkLayer.java; my own design):
  textures/entity/shark/skin.png    grey-blue shark hide, a pale belly and throat, gill slits on the neck, darker
                                    stripes down the back; the eyes and the outer (hat/jacket) layer left clear
  textures/entity/shark/rough.png   Rough Skin hardened: a pale, gritty sheen of scales over everything
Run: python3 tools/make_shark.py
"""
import os
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts", "textures", "entity", "shark")

# base-layer boxes: (u, v, w, h, d)
PARTS = {"head": (0, 0, 8, 8, 8), "body": (16, 16, 8, 12, 4), "right_arm": (40, 16, 4, 12, 4),
         "left_arm": (32, 48, 4, 12, 4), "right_leg": (0, 16, 4, 12, 4), "left_leg": (16, 48, 4, 12, 4)}


def faces(u, v, w, h, d):
    return {"top": (u + d, v, w, d), "bottom": (u + d + w, v, w, d), "right": (u, v + d, d, h),
            "front": (u + d, v + d, w, h), "left": (u + d + w, v + d, d, h), "back": (u + 2 * d + w, v + d, w, h)}


def skin():
    rng = np.random.default_rng(3)
    img = np.zeros((64, 64, 4))
    hide = np.array([92, 120, 146]); belly = np.array([206, 214, 220]); dark = np.array([58, 80, 102])
    for name, box in PARTS.items():
        for f, (x, y, w, h) in faces(*box).items():
            for j in range(h):
                for i in range(w):
                    c = hide.copy()
                    if f in ("top", "back"):
                        c = dark if (i + j // 3) % 4 == 0 else hide * 0.9
                    if name == "body" and f == "front":
                        c = belly if 2 <= i <= 5 else hide
                    if name == "head" and f == "front" and j >= 5:
                        c = belly                      # the pale jaw and throat
                    c = np.clip(np.array(c, float) + rng.normal(0, 4, 3), 0, 255)
                    img[y + j, x + i] = (*c, 235)
    # gill slits: three dark lines on each side of the neck (head sides, lower half)
    for x0 in (0, 16):
        for k in range(3):
            img[13:16, x0 + 2 + k * 2] = (34, 44, 56, 255)
    # the eyes show through, with a dark ring round them; a wide dark mouth line
    for ex in (9, 14):
        img[12, ex] = (0, 0, 0, 0)
        img[12, ex + (1 if ex == 9 else -1)] = (0, 0, 0, 0)
    img[14, 9:15] = (30, 36, 44, 255)
    Image.fromarray(img.astype(np.uint8), "RGBA").save(os.path.join(OUT, "skin.png"))


def rough():
    rng = np.random.default_rng(8)
    img = np.zeros((64, 64, 4))
    for box in PARTS.values():
        for (x, y, w, h) in faces(*box).values():
            for j in range(h):
                for i in range(w):
                    v = 200 + rng.integers(-30, 40)
                    a = 120 if (i + j) % 2 == 0 else 60      # a checker of scales catching the light
                    img[y + j, x + i] = (v, v + 8, v + 14, a)
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA").save(os.path.join(OUT, "rough.png"))


if __name__ == "__main__":
    skin()
    rough()
    print("shark textures written")
